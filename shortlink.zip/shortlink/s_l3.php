<?php 
    include_once'config/Session.php';    
    include_once'config/Database.php';
    include_once'config/Utilities.php'; 
    include_once'Setting.php';

            if(!isset($_SESSION['username'])) {header('Location: index.php');}
            if(isset($_POST['SlinkBtn'])){
            $user = $_SESSION['username'];
  $S_Verify = 1;
  $Paid = 1;
  $S_Verify1 = 0;
  $Paid1 = 0;
  $timestamp = date('Y-m-d H:i:s');
  $datebefore = date('Y-m-d H:i:s', strtotime('-24 hour'));
   
  $q1 = "SELECT * FROM Claimlog WHERE address =:user AND time > :time2 AND S_Verify = :S_Verify AND Paid =:Paid ";
            $statement = $db->prepare($q1);
            $statement->execute(array(':user' => $user , ':time2' => $datebefore , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
            if($statement->rowCount() > 0){

            //fetch data from DB & compare it with inputted data 
            while($row1 = $statement->fetch()){
                $already1 = $row1['shortlink1'];
                $already2 = $row1['shortlink2'];
  $q2 = "SELECT * FROM Shortlink_selected WHERE shortlink != :already1 AND shortlink != :already2 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2);
            $statement->execute(array(':already1'=> $already1, ':already2'=> $already2));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($row = $statement->fetch()){
                $newlink1 = $row['shortlink'];
                $apitoken1 = $row['api']; 
                }
  $q2a = "SELECT * FROM Shortlink_selected WHERE shortlink != :already1 AND shortlink != :already2 AND shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2a);
            $statement->execute(array(':already1'=> $already1, ':already2'=> $already2, ':newlink1'=> $newlink1));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($rowa = $statement->fetch()){
                $newlink2 = $rowa['shortlink'];
                $apitoken2 = $rowa['api']; 
                }               
                }
             else{ 
  $q2b = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2b);
            $statement->execute(array(':newlink1' => $newlink1));
            while($rowb = $statement->fetch()){
                $newlink2 = $rowb['shortlink'];
                $apitoken2 = $rowb['api']; } 
                }
             }
            else{
  $q2c = "SELECT * FROM Shortlink_selected ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2c);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($rowc = $statement->fetch()){
            $newlink1 = $rowc['shortlink'];
            $apitoken1 = $rowc['api']; 
            }  
  $q2d = "SELECT * FROM Shortlink_selected WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2d);
            $statement->execute(array(':newlink1' => $newlink1));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($rowd = $statement->fetch()){
            $newlink2 = $rowd['shortlink'];
            $apitoken2 = $rowd['api']; 
            } }
            else{
   $q2da = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2da);
            $statement->execute(array(':newlink1' => $newlink1));
            while($rowda = $statement->fetch()){
                $newlink2 = $rowda['shortlink'];
                $apitoken2 = $rowda['api']; } 
                } }
                else{
  $q3 = "SELECT * FROM SL_oth ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q3);
            $statement->execute(array());
            while($row3 = $statement->fetch()){
                $newlink1 = $row3['shortlink'];
                $apitoken1 = $row3['api']; } 
  $q4 = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q4);
            $statement->execute(array(':newlink1' => $newlink1));
            while($row1 = $statement->fetch()){
                $newlink2 = $row1['shortlink'];
                $apitoken2 = $row1['api']; } 
                } }                
                } }
               else{
               
  $q2 = "SELECT * FROM Shortlink_selected WHERE prt = 'Yes' ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($row = $statement->fetch()){
                $newlink1 = $row['shortlink'];
                $apitoken1 = $row['api']; 
                }
  $q2a = "SELECT * FROM Shortlink_selected WHERE shortlink != :newlink1 AND prt = 'Yes' ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2a);
            $statement->execute(array(':newlink1'=> $newlink1));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($rowa = $statement->fetch()){
                $newlink2 = $rowa['shortlink'];
                $apitoken2 = $rowa['api']; 
                }               
                }
             else{ 
  $q2b = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2b);
            $statement->execute(array(':newlink1' => $newlink1));
            while($rowb = $statement->fetch()){
                $newlink2 = $rowb['shortlink'];
                $apitoken2 = $rowb['api']; } 
                }
             }
            else{
  $q2c = "SELECT * FROM Shortlink_selected ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2c);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($rowc = $statement->fetch()){
            $newlink1 = $rowc['shortlink'];
            $apitoken1 = $rowc['api']; 
            }  
  $q2d = "SELECT * FROM Shortlink_selected WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2d);
            $statement->execute(array(':newlink1' => $newlink1));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($rowd = $statement->fetch()){
            $newlink2 = $rowd['shortlink'];
            $apitoken2 = $rowd['api']; 
            } }
            else{
   $q2da = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2da);
            $statement->execute(array(':newlink1' => $newlink1));
            while($rowda = $statement->fetch()){
                $newlink2 = $rowda['shortlink'];
                $apitoken2 = $rowda['api']; } 
                } }
                else{
  $q3 = "SELECT * FROM SL_oth ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q3);
            $statement->execute(array());
            while($row3 = $statement->fetch()){
                $newlink1 = $row3['shortlink'];
                $apitoken1 = $row3['api']; } 
  $q4 = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q4);
            $statement->execute(array(':newlink1' => $newlink1));
            while($row1 = $statement->fetch()){
                $newlink2 = $row1['shortlink'];
                $apitoken2 = $row1['api']; } 
                } } }

  $captcha_num = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
  $captcha_num = substr(str_shuffle($captcha_num), 0, 30);

  $surl1 = trim($newlink1);
  $apikey1 = trim($apitoken1);
  $http = "https://" ;
  $returnurl1 = urlencode("http://".$site."/check.php?k=".$captcha_num);
  $url1 = $http.$surl1."/api?api=".$apikey1."&url=".$returnurl1."&format=text";
  $short_link1 = @file_get_contents($url1);
  
  if(!empty($short_link1)){
  $surl2 = trim($newlink2);
  $apikey2 = trim($apitoken2);
  $returnurl2 = urlencode($short_link1);
  $url2 = $http.$surl2."/api?api=".$apikey2."&url=".$returnurl2."&format=text";
  $short_link2 = @file_get_contents($url2);
  if(!empty($short_link2)){
   $sqlupd = "UPDATE Claimlog SET address = :user,ip = :user_ip,time = :timestamp,shortlink1 = :newlink1,shortlink2 = :newlink2,v_code = :captcha_num,reward = :reward WHERE address = :user AND S_Verify = '0' AND Paid = '0'";

                //sanitise data
                $statement = $db->prepare($sqlupd);

                //Add data into the db 
                $statement->execute(array(':user' => $user, ':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink1' => $surl1 , ':newlink2' => $surl2 , ':captcha_num' => $captcha_num, ':reward' => $reward, ':user' => $user ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){
            header("Location: ". $short_link2);
            echo '<script> window.location.href="' .$short_link2. '"; </script>';
            die('Redirecting you to short link, please wait ...');
            }
      else{ $result = "Short link update failed1 ";} //check purpose only
      }
      else{
  $q5 = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q5);
            $statement->execute(array(':newlink1' => $newlink1));
            while($row5 = $statement->fetch()){
                $newlink2 = $row5['shortlink'];
                $apitoken2 = $row5['api']; }
  $surl2 = trim($newlink2);
  $apikey2 = trim($apitoken2);
  $returnurl2 = urlencode($short_link1);
  $url2 = $http.$surl2."/api?api=".$apikey2."&url=".$returnurl2."&format=text";
  $short_link2 = @file_get_contents($url2);
  if(!empty($short_link2)){
      $sqlupd1 = "UPDATE Claimlog SET address = :user,ip = :user_ip,time = :timestamp,shortlink1 = :newlink1,shortlink2 = :newlink2,v_code = :captcha_num,reward = :reward WHERE address = :user AND S_Verify = '0' AND Paid = '0'";

                //sanitise data
                $statement = $db->prepare($sqlupd1);

                //Add data into the db 
                $statement->execute(array(':user' => $user, ':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink1' => $surl1 , ':newlink2' => $surl2 , ':captcha_num' => $captcha_num, ':reward' => $reward, ':user' => $user ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){
            header("Location: ". $short_link2);
            echo '<script> window.location.href="' .$short_link2. '"; </script>';
            die('Redirecting you to short link, please wait ...');        
      }
      else{ $result = "Short link inserted failed2 ";} 
      }
      else{
      header('Location: index.php');
      }
      }}
      else{
  $q6 = "SELECT * FROM SL_oth ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q6);
            $statement->execute(array());
            while($row6 = $statement->fetch()){
                $newlink1 = $row6['shortlink'];
                $apitoken1 = $row6['api']; } 
            $q7 = "SELECT * FROM SL_oth  WHERE shortlink != :newlink1 ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q7);
            $statement->execute(array(':newlink1' => $newlink1));
            while($row7 = $statement->fetch()){
                $newlink2 = $row7['shortlink'];
                $apitoken2 = $row7['api']; } 
  $surl1 = trim($newlink1);
  $apikey1 = trim($apitoken1);
  $http = "https://" ;
  $returnurl1 = urlencode("http://".$site."/check.php?k=".$captcha_num);
  $url1 = $http.$surl1."/api?api=".$apikey1."&url=".$returnurl1."&format=text";
  $short_link1 = @file_get_contents($url1);
  
  if(!empty($short_link1)){
  $surl2 = trim($newlink2);
  $apikey2 = trim($apitoken2);
  $returnurl2 = urlencode($short_link1);
  $url2 = $http.$surl2."/api?api=".$apikey2."&url=".$returnurl2."&format=text";
  $short_link2 = @file_get_contents($url2);
  if(!empty($short_link2)){
   $sqlupd3 = "UPDATE Claimlog SET address = :user,ip = :user_ip,time = :timestamp,shortlink1 = :newlink1,shortlink2 = :newlink2,v_code = :captcha_num,reward = :reward WHERE address = :user AND S_Verify = '0' AND Paid = '0'";

                //sanitise data
                $statement = $db->prepare($sqlupd3);

                //Add data into the db 
                $statement->execute(array(':user' => $user, ':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink1' => $surl1 , ':newlink2' => $surl2 , ':captcha_num' => $captcha_num, ':reward' => $reward, ':user' => $user ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){
            header("Location: ". $short_link2);
            echo '<script> window.location.href="' .$short_link2. '"; </script>';
            die('Redirecting you to short link, please wait ...');        
      }
       else{ $result = "Short link inserted failed3 ";} 
      }
       else{ 
       header('Location: index.php');
       }
      }
       else{ 
       header('Location: index.php');
       }
      } }
       else{ header('Location: index.php');}           
?>