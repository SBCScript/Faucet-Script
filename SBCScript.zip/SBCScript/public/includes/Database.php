<?php 

    define("DSN", "mysql:host=localhost;dbname=bitcoins_F");
    define("USERNAME", "bitcoins_fau");
    define("PWD", "*#Aa3456789Bb#*");


	

	try {
            
            //Create the connection 
            $db = new PDO(DSN, USERNAME, PWD);
            
            //set the PDO error mode to exception
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	}
	catch (PDOException $ex) {
            //Display error message
            echo "Connection failed ".$ex->getMessage();
        }
        $admusr = "admin_username" ; //admin username with secret word and don't use cryptoaddress
        $admpass = "admin_password" ;  //admin password with strength strong




	