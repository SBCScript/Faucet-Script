<?php 
    include_once'config/Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';
    include_once'header.php';
?>
     <div style="text-align:center;background-color:yellow;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toplad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;">
     <?php echo $adpop ; ?>
                  <h2 style="color:purple;"><?php echo $sitesdes ; ?></h2>  
     </div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toprad ; ?></center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlelad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <ul style='background-color:MistyRose;color:red;'>
                  Session expired</ul>
                  <?php else: ?>
		 <ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></h3></ul>
		<br><br>
<?php           $user = $_SESSION['username'];
                $S_Verify = 1;
                $Paid = 1;
                $S_Verify1 = 0;
                $Paid1 = 0;
                $date = date('Y-m-d H:i:s');
            if(isset($_POST['ClamBtn'])){
                //again check for pending payout for cheat request
                $qchecka = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify AND Paid =:Paid1";
                $statement = $db->prepare($qchecka);
                $statement->execute(array(':user' => $user , ':S_Verify' => $S_Verify,':Paid1' => $Paid1 ));
                if($statement->rowcount()>0){ $pay = 'pass'; }
                else{ $resultw = "Cheating request payout can suspend your account.."; }
                if($pay == 'pass'){
                $user1 = $_POST['usrn'];
                if($user == $user1){ 
                $qusrdtl = "SELECT * FROM Claim_Addresses WHERE address =:user ";
                $statement = $db->prepare($qusrdtl);
                $statement->execute(array(':user' => $user));
                //fetch data from DB & compare it with inputted data 
                while($row = $statement->fetch()){
                $ref_add = $row['ref_add'];
                $pbalance = $row['balance'];
                }
                $qupdclg = "UPDATE Claimlog SET ip = :ip ,time = :timestamp ,Paid =:Paid WHERE address =:user AND S_Verify = :S_Verify AND Paid =:Paid1 ";
	        $statement = $db->prepare($qupdclg);
                $statement->execute(array(':ip' => $user_ip ,':timestamp' => $date ,':Paid' => $Paid ,':user' => $user ,':S_Verify' => $S_Verify ,':Paid1' => $Paid1));

                $newbalance = $pbalance + $reward;
                
                $qupdusr = "UPDATE Claim_Addresses SET balance = :newbalance WHERE address = :user";
	        $statement = $db->prepare($qupdusr);
                $statement->execute(array(':newbalance' => $newbalance ,':user' => $user));
                
                if($ref_add != '0'){
                $qrefdtl = "SELECT * FROM Claim_Addresses WHERE address =:ref ";
                $statement = $db->prepare($qrefdtl);
                $statement->execute(array(':ref' => $ref_add));
                //fetch data from DB & compare it with inputted data 
                while($row1 = $statement->fetch()){
                $refbalance = $row1['balance'];
                }
                $ref_newbalance = $refbalance + $refcomsn ;
                $qupdref = "UPDATE Claim_Addresses SET balance = :ref_newbalance WHERE address = :ref_add";
	        $statement = $db->prepare($qupdusr);
                $statement->execute(array(':ref_newbalance' => $ref_newbalance ,':ref_add' => $ref_add));
                }
                $results = "Your account credit with ".$reward." Satoshi of ".$currency ;
                }
                else{ $resultw = "Verification failed! please try again.."; }
                }
                }
?>
              <?php if(isset($resultw)){?>
              <div style='background-color:mistyrose;color:red;'>
              <?php echo $resultw; ?>
              </div><br><?php } ?>
              <?php if(isset($results)){?>
              <div style='background-color:palegreen;color:green;'>
              <?php echo $results; ?>
              </div><br>
              <?php $div = "<div id='inv' style='display:none'>" ;}
              else{ $div ="<div>" ;}?>
              
<?php echo $div; ?>
<?php           //check for pending payout
                $qcheck = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify AND Paid =:Paid1";
                $statement = $db->prepare($qcheck);
                $statement->execute(array(':user' => $user , ':S_Verify' => $S_Verify,':Paid1' => $Paid1 ));
                if($statement->rowcount()>0){ ?>

              <div style='background-color:LightCyan;color:mediumpurple;'>
              <h4> Verify anti bot captcha for claim your reward </h4>
              </div>
              <br>
              <script src="https://authedmine.com/lib/captcha.min.js" async></script>
	      <script>
	      function myCaptchaCallback(token){
	      document.getElementById('hide').style.display='block';}
	      </script>
	      <div class="coinhive-captcha" 
		data-hashes="512" 
		data-key="tHQBzIyPksmAoB7Msz8i1Me8niVUcrHw"
		data-whitelabel="true"
		data-callback="myCaptchaCallback">
		<em>Loading Captcha...<br />
		If it doesnot load, please disable Adblock!</em>
	      </div>
	      <div id="hide" style="display:none">
	      <form action='' method='POST'>
	      <input type = 'hidden' name='usrn' value='<?php echo $user ; ?>' >
	      <input name='ClamBtn' type='submit' value='claim now' style='width:200px;height:60px;background-color:blue;color:white;'>
	      </form>
	      </div>
	      
<?php
              }
          else{ ?>
                  <ul style='background-color:MistyRose;color:red;'>
                  Currently there is no any pending payout.please watch the faucet home page</ul>
<?php         }      ?></div>
	      
               <?php  endif; ?>
              </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlerad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
     <div style="text-align:center;background-color:white;color:green;padding:10px;">
     <p>Referral link http://<?php echo $site ; ?>/?r=<?php if(isset($_SESSION['username'])){echo $_SESSION['username'] ;} else{echo"Your_account_address";} ?></p>
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomlad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:650px;hight:600px;">
     <center>
     <div style="background-color:aquamarine;color:green;padding:20px;">     <?php		 
// recent payout
 $S_Verify = 1;
 $Paid = 1;
 $qrecent = "SELECT address, time, reward FROM Claimlog WHERE S_Verify = :S_Verify AND Paid = :Paid  ORDER BY id DESC LIMIT 10";
    $statement = $db->prepare($qrecent);
    $statement->execute(array(':S_Verify' => $S_Verify,':Paid' => $Paid ));
    if($statement->rowCount()>0) {
        echo'<h3>Recent Payouts</h3><table class="recent-payouts" border="1"><tr><th class="list-left" width="50%" >Date</th><th class="list-center" width="100%">Address</th><th class="list-right" width="50%">Reward</th></tr>';
        while($rowrec = $statement->fetch()){
            echo '<td class="list-left"><center>'.$rowrec['time'].'</center></td>';
            echo '<td class="list-center"><center>'.$rowrec['address'].'</center></td>';
            echo '<td class="list-right"><center>'.$rowrec['reward'].'</center></td>';
            echo '<tr>';
        }
        echo '</table>'; }
?>
</div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomrad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
<?php        include_once'footer.php';
    ?>