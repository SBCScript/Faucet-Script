<?php
    include_once'config/Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/

    include_once'config/Database.php';
    include_once'config/Utilities.php'; 
    include_once'Setting.php';
    if(!isset($_SESSION['username'])){ header('Location: index.php'); }
    if(isset($_GET['k'])) { $GET = $_GET['k'];
    $user = $_SESSION['username'];
  $S_Verify = 1;
  $Paid = 1;
  $S_Verify1 = 0;
  $Paid1 = 0;

  $qcheck = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify1 AND Paid =:Paid1";  
            $statement = $db->prepare($qcheck);
            $statement->execute(array(':user' => $user , ':S_Verify1' => $S_Verify1,':Paid1' => $Paid1 ));
            if($statement->rowcount()>0){
            //fetch data from DB & compare it with inputted data 
            while($row = $statement->fetch()){
                $qfetch = trim($row['v_code']);} 

    if($GET == $qfetch){
    $qupdate = "UPDATE Claimlog SET S_Verify =:S_Verify WHERE address =:user AND v_code = :GET AND Paid =:Paid1";
    
                $statement = $db->prepare($qupdate);

                $statement->execute(array(':S_Verify' => $S_Verify,':user' => $user , ':GET' => $GET, ':Paid1' => $Paid1 ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){
          header('Location: payout.php');
    }     
      else{ header('Location: index.php'); //on failed updating data
      }
      }
  else{ header('Location: index.php'); }
}
            else{ header('Location: index.php'); }
     
}
else{ header('Location: index.php');}

?>