<?php 
    include_once'config/Session.php';    
    include_once'config/Database.php';
    if(isset($_SERVER['HTTPS'] ) ) { $svr = "https://";}
    else{$svr = "http://";}
    include_once'config/Utilities.php'; 
    include_once'Setting.php';
    
            if(!isset($_SESSION['username'])) {header('Location: index.php');}
            if(isset($_POST['SLVBtn'])){
            $user = $_SESSION['username'];
  $S_Verify = 1;
  $Paid = 1;
  $S_Verify1 = 0;
  $Paid1 = 0;
  $timestamp = date('Y-m-d H:i:s');
  $datebefore = date('Y-m-d H:i:s', strtotime('-24 hour'));
                
  $qcd = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify1 AND Paid =:Paid1";
            $statement = $db->prepare($qcd);
            $statement->execute(array(':user' => $user , ':S_Verify1' => $S_Verify1,':Paid1' => $Paid1 ));
            if($statement->rowCount() > 0){ $delpass = 'true';}
            else{ $delpass = 'fail';}
            if($delpass == 'true'){
  $qdtlog = "DELETE FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify1 AND Paid =:Paid1";
            $statement = $db->prepare($qdtlog);
            $statement->execute(array(':user' => $user , ':S_Verify1' => $S_Verify1,':Paid1' => $Paid1 )); }
            
  $q1 = "SELECT * FROM Claimlog WHERE address =:user AND time > :time2 AND S_Verify = :S_Verify AND Paid =:Paid";
            $statement = $db->prepare($q1);
            $statement->execute(array(':user' => $user ,':time2' => $datebefore , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
            if($statement->rowCount() > 0){

            //fetch data from DB & compare it with inputted data 
            while($row1 = $statement->fetch()){
                $already = $row1['shortlink1'];
 $q2 = "SELECT * FROM Shortlink_selected WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2);
            $statement->execute(array(':already'=> $already));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($row2 = $statement->fetch()){
                $newlink1 = $row2['shortlink'];
                $apitoken1 = $row2['api']; } }
            else{$q3 = "SELECT * FROM Shortlink_selected ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q3);
            $statement->execute(array());
            if($statement->rowcount() > 0){
            while($row3 = $statement->fetch()){
                $newlink1 = $row3['shortlink'];
                $apitoken1 = $row3['api']; } }
            else{$q4 = "SELECT * FROM SL_oth WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q4);
            $statement->execute(array(':already' => $already));
            while($row4 = $statement->fetch()){
                $newlink1 = $row4['shortlink'];
                $apitoken1 = $row4['api']; } } }               
                 }}
               else{
  $q2 = "SELECT * FROM Shortlink_selected WHERE prt = 'Yes' ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($row2 = $statement->fetch()){
                $newlink1 = $row2['shortlink'];
                $apitoken1 = $row2['api']; } }
            else{$q3 = "SELECT * FROM Shortlink_selected ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q3);
            $statement->execute(array());
            if($statement->rowcount() > 0){
            while($row3 = $statement->fetch()){
                $newlink1 = $row3['shortlink'];
                $apitoken1 = $row3['api']; } }
            else{$q4 = "SELECT * FROM SL_oth WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q4);
            $statement->execute(array(':already' => $already));
            while($row4 = $statement->fetch()){
                $newlink1 = $row4['shortlink'];
                $apitoken1 = $row4['api']; } } } }
  
  $captcha_num = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
  $captcha_num = substr(str_shuffle($captcha_num), 0, 30);

  $surl = trim($newlink1);
  $apikey = trim($apitoken1);
  $http = "https://" ;
  $returnurl = urlencode($svr.$site."/check.php?k=".$captcha_num);
  $url = $http.$surl."/api?api=".$apikey."&url=".$returnurl."&format=text";

  $short_link = @file_get_contents($url);
  if(!empty($short_link)){
   $sqlInsert = "INSERT INTO Claimlog (address,ip,time,shortlink1,shortlink2,v_code,reward,S_Verify,Paid) VALUES (:user, :user_ip, :timestamp,:newlink1,'none',:captcha_num,:reward,'0','0')";

                //sanitise data
                $statement = $db->prepare($sqlInsert);

                //Add data into the db 
                $statement->execute(array(':user' => $user, ':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink1' => $surl , ':captcha_num' => $captcha_num, ':reward' => $reward ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){
          header("Location: ". $short_link);
            echo '<script> window.location.href="' .$short_link. '"; </script>';
            die('Redirecting you to short link, please wait ...');        
      }
      else{ $result = "Short link insert fail on first placer";} //test purpose only
      }
    else{$q5 = "SELECT * FROM SL_oth WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q5);
            $statement->execute(array(':already' => $already));
            while($row5 = $statement->fetch()){
                $newlink1 = $row5['shortlink'];
               $apitoken1 = $row5['api']; }  
  $captcha_num1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
  $captcha_num1 = substr(str_shuffle($captcha_num1), 0, 30);

  $surl1 = trim($newlink1);
  $apikey1 = trim($apitoken1);
  $http1 = "https://" ;
  
  $returnurl1 = urlencode($svr.$site."/check.php?k=".$captcha_num1);
  $url1 = $http1.$surl1."/api?api=".$apikey1."&url=".$returnurl1."&format=text";

  $short_link1 = @file_get_contents($url1); 
  if(!empty($short_link1)){ 
  $sqlInsert = "INSERT INTO Claimlog (address,ip,time,shortlink1,shortlink2,v_code,reward,S_Verify,Paid) VALUES (:user, :user_ip, :timestamp,:newlink1,'none',:captcha_num1,:reward,'0','0')";

                //sanitise data
                $statement = $db->prepare($sqlInsert);

                //Add data into the db 
                $statement->execute(array(':user' => $user, ':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink' => $surl1 , ':captcha_num1' => $captcha_num1, ':reward' => $reward ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){ 
          header("Location: ". $short_link1);
            echo '<script> window.location.href="' .$short_link1. '"; </script>';
            die('Redirecting you to short link, please wait ...');        
      }
      else{ $result = "Short link insert fail on second placer";}}
      else { 
      header('Location: index.php');}
 }
}
 else { header('Location: index.php');}           
?>