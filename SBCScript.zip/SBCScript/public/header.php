<?php 
	include_once'config/Session.php';
	include_once'Setting.php';
	include_once'checkfbalance.php';
?>
<!DOCTYPE html>
<html lang="en"> 
  <head> 
    <meta charset="utf-8" />  
    <!-- Change for better search engine indexing -->  
    <title><?php echo $page_title ; ?>|Script4download.blogspot.com</title>  
    <meta name="title" content="<?php $sitenm ; ?>" />  
    <meta name="description" content="<?php $sitesdes ; ?>" />  
    <meta name="keywords" content="<?php $sitekeyw ; ?>" />  
    <meta name="subject" content="Crypto currency free reward" />  
    <meta name="robots" content="All" />  
    <meta name="abstract" content="<?php $siteldes ; ?>" />  
    <meta name="MSSmartTagsPreventParsing" content="true" />  
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto+Condensed|Roboto+Condensed|Droid+Sans|Droid+Sans|Droid+Sans|Droid+Sans" type="text/css" />  
  </head>  
  <body style ="margin:0;padding:0;height: 100%;"> 
    <div width="auto" style="background-color:violet;padding:5px"> 
     <div style="text-align:center;background-color:yellow;">
     <H1 style="color:steelblue;font-family:verdana;font-size:200%;"><?php echo $sitenm ; ?></H1>
     <ul style="list-style-type: none;margin: 0;padding: 0;overflow: hidden;background-color: yellowgreen;">
     <li style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="index.php">Home</a>
     </li>
     <li style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="#offer.php">Offerwall</a>
     </li>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="faqs.php">Faqs</a>
     </li>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="news.php">News</a>
     </li>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="payment_proof.php">Payment Proof</a>
     </li>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="#contactlinkhere">Contact</a>
     </li>
     <?php if(isset($_SESSION['username'])){ ?>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="withdraw.php">Withdraw</a>
     </li>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="logout.php">Logout</a>
     </li>
     <?php } ?>
     <li style="float: right;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;">Faucet balance is <?php echo $balance ; ?> satoshis</a>
     </li>
     </ul>
    </div>