<?php
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';

      $qcheckbip = "SELECT * FROM Blackip WHERE ip_add =:ip ";
                $statement = $db->prepare($qcheckbip);
                $statement->execute(array(':ip' => $user_ip ));
                if($statement->rowcount()>0){
                $reslutip = 'Fail';}
 else {$qcheckwip = "SELECT * FROM Whiteip WHERE ip_add =:ip ";
                $statement = $db->prepare($qcheckwip);
                $statement->execute(array(':ip' => $user_ip ));
                if($statement->rowcount()>0){
                $reslutip = 'Pass';}
 else {
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_URL, 'http://v2.api.iphub.info/ip/'.$user_ip);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-Key: your_iphub_api'));
      $response = curl_exec($ch);
      curl_close($ch);
 
      $obj = json_decode($response, true);
      if($obj['block'] == '1'){
               $qinsbip = "INSERT INTO Blackip (ip_add) VALUES (:IP)";
               $statement = $db->prepare($qinsbip);
               $statement->execute(array(':IP' => $user_ip));
               $reslutip = 'Fail';  }
     else {    $qinswip = "INSERT INTO Whiteip (ip_add) VALUES (:IP)";
               $statement = $db->prepare($qinswip);
               $statement->execute(array(':IP' => $user_ip));
               $reslutip = 'Pass';  } } }
?>