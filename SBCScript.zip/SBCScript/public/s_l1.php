<?php 
    include_once'config/Session.php';    
    include_once'config/Database.php';
    include_once'config/Utilities.php'; 
    include_once'Setting.php';

            if(!isset($_SESSION['username'])) {header('Location: index.php');}
            if(isset($_POST['SlinkBtn'])){
            $user = $_SESSION['username'];
  $S_Verify = 1;
  $Paid = 1;
  $S_Verify1 = 0;
  $Paid1 = 0;
  $timestamp = date('Y-m-d H:i:s');
  $datebefore = date('Y-m-d H:i:s', strtotime('-24 hour'));
                
  $q1 = "SELECT * FROM Claimlog WHERE address =:user AND time > :time2 AND S_Verify = :S_Verify AND Paid =:Paid";
            $statement = $db->prepare($q1);
            $statement->execute(array(':user' => $user ,':time2' => $datebefore , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
            if($statement->rowCount() > 0){

            //fetch data from DB & compare it with inputted data 
            while($row1 = $statement->fetch()){
                $already = $row1['shortlink1'];
    $q2 = "SELECT * FROM Shortlink_selected WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2);
            $statement->execute(array(':already'=> $already));

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($row2 = $statement->fetch()){
                $newlink1 = $row2['shortlink'];
                $apitoken1 = $row2['api']; } }
            else{$q3 = "SELECT * FROM Shortlink_selected ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q3);
            $statement->execute(array());
            if($statement->rowcount() > 0){
            while($row3 = $statement->fetch()){
                $newlink1 = $row3['shortlink'];
                $apitoken1 = $row3['api']; } }
            else{$q4 = "SELECT * FROM SL_oth WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q4);
            $statement->execute(array(':already' => $already));
            while($row4 = $statement->fetch()){
                $newlink1 = $row4['shortlink'];
                $apitoken1 = $row4['api']; } } }            
                } }
               else{
  $q2 = "SELECT * FROM Shortlink_selected WHERE prt = 'Yes' ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q2);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            if($statement->rowcount() > 0){while($row2 = $statement->fetch()){
                $newlink1 = $row2['shortlink'];
                $apitoken1 = $row2['api']; } }
            else{$q3 = "SELECT * FROM Shortlink_selected ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q3);
            $statement->execute(array());
            if($statement->rowcount() > 0){
            while($row3 = $statement->fetch()){
                $newlink1 = $row3['shortlink'];
                $apitoken1 = $row3['api']; } }
            else{$q4 = "SELECT * FROM SL_oth WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q4);
            $statement->execute(array(':already' => $already));
            while($row4 = $statement->fetch()){
                $newlink1 = $row4['shortlink'];
                $apitoken1 = $row4['api']; } } } }
  
  $captcha_num = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
  $captcha_num = substr(str_shuffle($captcha_num), 0, 30);

  $surl = trim($newlink1);
  $apikey = trim($apitoken1);
  $http = "https://" ;
  $returnurl = urlencode("https://".$site."/check.php?k=".$captcha_num);
  $url = $http.$surl."/api?api=".$apikey."&url=".$returnurl."&format=text";

  $short_link = @file_get_contents($url);
  if(!empty($short_link)){
   $sqlupdate = "UPDATE Claimlog SET ip = :user_ip ,time = :timestamp ,shortlink1 = :newlink,shortlink2 = 'none',v_code = :captcha_num WHERE address = :user AND S_Verify = :S_Verify1 AND Paid = :Paid1";

                //sanitise data
                $statement = $db->prepare($sqlupdate);

                //Add data into the db 
                $statement->execute(array(':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink' => $surl , ':captcha_num' => $captcha_num, ':user' => $user, ':S_Verify1' => $S_Verify1, ':Paid1' => $Paid1 ));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){
          header("Location: ". $short_link);
            echo '<script> window.location.href="' .$short_link. '"; </script>';
            die('Redirecting you to short link, please wait ...');        
      }
      else{ $result = "Shortlink preparation fail on first placer";} 
      }
    else{$q5 = "SELECT * FROM SL_oth WHERE shortlink != :already ORDER BY RAND() LIMIT 1";
            $statement = $db->prepare($q5);
            $statement->execute(array(':already' => $already));
            while($row5 = $statement->fetch()){
                $newlink1 = $row5['shortlink'];
               $apitoken1 = $row5['api']; }  
  $captcha_num1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
  $captcha_num1 = substr(str_shuffle($captcha_num1), 0, 30);

  $surl1 = trim($newlink1);
  $apikey1 = trim($apitoken1);
  $http1 = "https://" ;
  
  $returnurl1 = urlencode("https://".$site."/check.php?k=".$captcha_num1);
  $url1 = $http1.$surl1."/api?api=".$apikey1."&url=".$returnurl1."&format=text";

  $short_link1 = @file_get_contents($url1); 
  if(!empty($short_link1)){ 
  $sqlupdate = "UPDATE Claimlog SET ip = :user_ip ,time = :timestamp ,shortlink1 = :newlink, shortlink2 = 'none', v_code = :captcha_num WHERE address = :user AND S_Verify = :S_Verify1 AND Paid = :Paid1";

                //sanitise data
                $statement = $db->prepare($sqlupdate);

                //Add data into the db 
                $statement->execute(array(':user_ip' => $user_ip, ':timestamp' => $timestamp, ':newlink' => $surl1 , ':captcha_num' => $captcha_num1, ':user' => $user, ':S_Verify1' => $S_Verify1, ':Paid1' => $Paid1 ));
                if($statement->rowCount() == 1){ 
          header("Location: ". $short_link1);
            echo '<script> window.location.href="' .$short_link. '"; </script>';
            die('Redirecting you to short link, please wait ...');       
      }
      else{ $result = "Shortlink preparation fail on second placer";}}
      else { header('Location: index.php');}
 }
}
 else { header('Location: index.php');}           
?>