<?php
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    $sqlQuery = "SELECT * FROM Setting";
            $statement = $db->prepare($sqlQuery);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            while($row = $statement->fetch()){
                $balance = $row['balance'];
                $sitenm = $row['sitename'];
                $sitesdes = $row['S_description'];
                $siteldes = $row['L_description'];
                $sitekeyw = $row['Site_keyword'];
                $adpop = $row['adpop'];
                $toplad = $row['top_left_ad'];
                $toprad = $row['top_right_ad'];
                $middlelad = $row['middle_left_ad'];
                $middlerad = $row['middle_right_ad'];
                $buttomlad = $row['bottom_left_ad'];
                $buttomrad = $row['bottom_right_ad'];
                $fauh_api = $row['api'];
                $currency = $row['currency'];
                $reward = $row['reward'];
                $refcomsn = $row['refercomsn'];
                $claimlimit = $row['claimlimit'];
                $timedif = $row['timediffernce'];
                $faucetstate = $row['active'];
                $shortlink_t = $row['shortlink_type'];
                $checkbltime = $row['check_balance_time'];
                $google_pk = $row['Google_pbk'];
                $google_sk = $row['Google_sck'];
                $min_casho = $row['min_cashout'];
                date_default_timezone_set("America/New_York");
                }
   if(isset($_SESSION['username']) && $faucetstate =='0'){
    //Signout finction
	signout();


	//Do not delete!!!
	//This will be moved shortly 

	
	/*//Unset all of the session vars
	$_SESSION = array(); 

	//This will kill the session & destroy any cookies
	if (ini_get("session.use_cookies")){
		$params = session_get_cookie_params();
		setcookie(session_name(), '', time() -42000,
			$params["path"], $params["domain"],
			$params["secure"], $params["httponly"]
		);
	}

	//Finally destroy the session
	session_destroy();

	redirectTo('index');*/

   }
                
$sqlQuery1 = "SELECT * FROM Fee_add WHERE currency = :currency ";
            $statement = $db->prepare($sqlQuery1);
            $statement->execute(array(':currency'=> $currency));

         //fetch data from DB & compare it with inputted data 
            while($row1 = $statement->fetch()){
                  $adminada = $row1['address'];
                  $admincomsn = $row1['comsn']; }
                  
             function getUserIP()
{
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}


$user_ip = getUserIP();

   
?>