<?php 
    include_once'Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/

    include_once'../includes/Database.php';
    include_once'../includes/Utilities.php';
    include_once'header.php';
    date_default_timezone_set("America/New_York");
    $date = date('Y-m-d H:i:s');
?>    
     <div style="text-align:center;background-color:white;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;"> 
                  <h2>Wellcone to your admin area</h2>  
     </div>
     </center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>
	<?php
                  elseif($_SESSION['username'] != $admusr):
        ?>	
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>		
		
		<?php else: ?>
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as admin of this site</h3></ul>
<?php                  
		if(isset($_POST['actBtn'])) {
		//Initilaise the array
		$form_errors = array();

		//form validation
		$required_fields = array('fau_st','fau_api','fau_crc');

		//check empty fields and merge into array
		$form_errors = array_merge($form_errors, check_empty_fields($required_fields));

		//Collect data from form
		$fau_st = $_POST['fau_st'];
		$fau_api = $_POST['fau_api'];
		$fau_crc = $_POST['fau_crc'];
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/balance");
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$fau_api&currency=$fau_crc");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		$check = json_decode($server_output,true);
		if($check['status'] == "200" && $check['message'] == "OK"){
		$balance = $check['balance'];
		
		if(empty($form_errors)){
			try{
				//create sql update
				$sqlUpdate = "UPDATE Setting SET balance = :balance, active = :fau_st, check_balance_time = :date";

				//Sanitise 
				$statement = $db->prepare($sqlUpdate);

				//update 
				$statement->execute(array(':balance' => $balance, ':fau_st' => $fau_st, ':date' => $date));

				//Check if one new row was created
				if($statement->rowCount() == 1){
					$results = 'update setting successful';
						
				}
				else {
					$resultw = 'Nothing change in setting';
						
				}
			}
			catch (PDOException $ex) {
				$resultw = "An error occured in: " .$ex->getMessage();
			}
		}
		else {
			if(count($form_errors) == 1) {
				$resultw = "There was 1 error in the form <br>";
			}
			else {
				$resultw = "There were " .count($form_errors). " errors in the form <br>";
			}
		}
	}
		else{ $resultw = $check['message'];}
}
		if(isset($_POST['inactBtn'])) {
		//Initilaise the array
		$form_errors = array();

		//form validation
		$required_fields = array('fau_st');

		//check empty fields and merge into array
		$form_errors = array_merge($form_errors, check_empty_fields($required_fields));

		//Collect data from form
		$fau_st = $_POST['fau_st'];
		
		if(empty($form_errors)){
			try{
				//create sql update
				$sqlUpdate = "UPDATE Setting SET active =:fau_st";

				//Sanitise 
				$statement = $db->prepare($sqlUpdate);

				//update 
				$statement->execute(array(':fau_st' => $fau_st));

				//Check if one new row was created
				if($statement->rowCount() == 1){
					$results = 'update setting successful';
						
				}
				else {
					$resultw = 'Nothing change in setting';
						
				}
			}
			catch (PDOException $ex) {
				$resultw = "An error occured in: " .$ex->getMessage();
			}
		}
		else {
			if(count($form_errors) == 1) {
				$resultw = "There was 1 error in the form <br>";
			}
			else {
				$resultw = "There were " .count($form_errors). " errors in the form <br>";
			}
		}
	}
	$sqlQuery = "SELECT * FROM Setting";
            $statement = $db->prepare($sqlQuery);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            while($row = $statement->fetch()){
                $fauh_api = $row['api'];
                $faucetstate = $row['active'];
                $crc = $row['currency'];
                }

		if($faucetstate =='0'){
		$div1 = "<div>" ;
                $div2 = "<div id='iv2' style='display:none'>"; 
          }
		else{
		$div1 = "<div id='iv1' style='display:none'>";
		$div2 = "<div>" ;
          }
?>
<?php		if(isset($resultw)){ ?>
		<ul style='background-color:Mistyrose;color:red;'>
                  <p><?php echo $resultw ; ?></p></ul>
<?php } ?>                  
<?php		if(isset($results)){ ?>
		<ul style='background-color:palegreen;color:green;'>
                  <p><?php echo $results ; ?></p></ul>
<?php } ?>                  
	                  
		<br><h4>Mange faucet</h4>
<?php echo $div1; ?>
                  <h4>Make the faucet active</h4>
                  <form action="" method="POST">
                  <input type="hidden" name="fau_st" value="1">
                  <input type="hidden" name="fau_api" value="<?php echo $fauh_api ; ?>">
                  <input type="hidden" name="fau_crc" value="<?php echo $crc ; ?>">
                  <p><input type="submit" style="width:100px;height:50px;background-color:blue;color:white;" name="actBtn" value="Active now">
                  </p>
		</form></div>
<?php echo $div2; ?>
                  <h4>Make the faucet inactive</h4>
                  <form action="" method="POST">
                  <input type="hidden" name="fau_st" value="0">
                  <p><input type="submit" style="width:100px;height:50px;background-color:blue;color:white;" name="inactBtn" value="Inactive now">
                  </p>
		</form></div>
		
              <?php  endif; ?>
              </center>
     </div>
     </td>
     </tr>
     </table>
     </div>
    
<?php        include_once'../footer.php';
    ?>