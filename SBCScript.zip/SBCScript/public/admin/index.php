<?php 
    include_once'Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/

    include_once'../includes/Database.php';
    include_once'ParseLogin.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:white;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;"> 
                  <h2>Wellcone to your admin area</h2>  
     </div>
     </center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <h2>Login</h2>
                  <br>
                  <ul style='background-color:MistyRose;color:red;'>
                  <?php if(isset($result)){ echo $result;} ?>
                  </ul>
                  <br>
                  <form action="" method="POST">
                  <input type="text" name="usr_adm" autocomplete="off" placeholder="username" style="width:200px;height:25px;" required>
                  <input type="password" name="usr_pass" autocomplete="off" placeholder ="password" style="width:200px;height:25px;" required>
                  <br><br>
                  <p><input type="submit" style="width:80px;height:50px;background-color:blue;color:white;" name="lgBtn" value="Submit">
                  </p>
		</form>
	<?php
                  elseif($_SESSION['username'] != $admusr):
        ?>	
                   <h2>Login</h2>
                  <br>
                  <ul style='background-color:MistyRose;color:red;'>
                  <?php if(isset($result)){ echo $result;} ?>
                  </ul>
                  <br>
                  <form action="" method="POST">
                  <input type="text" name="usr_adm" autocomplete="off" placeholder="username" style="width:200px;height:25px;" required>
                  <input type="password" name="usr_pass" autocomplete="off" placeholder ="password" style="width:200px;height:25px;" required>
                  <br><br>
                  <p><input type="submit" style="width:80px;height:50px;background-color:blue;color:white;" name="lgBtn" value="Submit">
                  </p>
		</form>
		<?php else: ?>
		
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as admin of this site</h3></ul>
		<br><h4>Mange faucet</h4>
		<center>
				<table border="1">
					<tr><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="Setting.php" target="_blank">Faucet setting</a></th><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="Settemp.php" target="_blank">Template setting (ads)</a></tr>
					<tr><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="shortlink.php" target="_blank">Shortlink manage</a></th><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="fau_act.php" target="_blank">Faucet active or inactive</a></th></tr>
					<tr><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="blackiplist.php" target="_blank">Black IP address manage</a></th><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="whiteiplist.php" target="_blank">White IP address manage</a></th></tr>
					<tr><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="addresslist.php" target="_blank">Black address manage</a></th><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="static.php" target="_blank">Faucet static</a></th></tr>
					<tr><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="faqmng.php" target="_blank">FAQs Manage </a></th><th><a style="display: block;background-color:yellowgreen;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="newsmng.php" target="_blank">Send Latest news</a></th></tr>
				</table>
			</center>
              <?php  endif; ?>
              </center>
     </div>
     </td>
     </tr>
     </table>
     </div>
    
<?php        include_once'../footer.php';
    ?>