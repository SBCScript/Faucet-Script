<?php 
    include_once'Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'../includes/Database.php';
    include_once'../includes/Utilities.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:white;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;"> 
                  <h2>Wellcone to your admin area</h2>  
     </div>
     </center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:900px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>
	<?php
                  elseif($_SESSION['username'] != $admusr):
        ?>	
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>		
		
		<?php else: ?>
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as admin of this site</h3></ul>
		
<?php
    $S_verify = 1;
    $Paid = 1;
    $start=0;
    $limit=30;
    if(isset($_GET['id'])){
        $id=$_GET['id'] ; 
        $start= ($id-1)*$limit;}
    else{$id=1;}
    $sqlQuery1 = "SELECT * FROM Claimlog WHERE S_Verify = :S_verify  AND Paid = :Paid ";
            $statement1 = $db->prepare($sqlQuery1);
            $statement1->execute(array(':S_verify' => $S_verify,':Paid' => $Paid ));
            if($statement1->rowcount()>0){
            $total = $statement1->rowcount();
            $page=ceil($total/$limit);
            
            $sqlQuery2 = "SELECT * FROM Claimlog WHERE S_Verify = :S_verify  AND Paid = :Paid limit $start, $limit ";
            $statement2 = $db->prepare($sqlQuery2);
            $statement2->execute(array(':S_verify' => $S_verify,':Paid' => $Paid )); ?>
            <div class="container">
  <h2>Static of your faucet</h2>
    <table class="table table-bordered">
    <thead>
      <tr>
       <th>claimed address</th>
       <th>shortlink1</th>
       <th>shortlink2</th>
       <th>time</th>
       <th>ip</th>
       </tr>
    </thead>
 <tbody>
<?php
  while($row1=$statement2->fetch()){?>
<tr>
<td><center><?= $row1['1']?></center></td>
<td><center><?= $row1['4']?></center></td>
<td><center><?= $row1['5']?></center></td>
<td><center><?= $row1['3']?></center></td>
<td><center><?= $row1['2']?></center></td>
</tr>   
<?php } ?>
</tbody>
</table>
 <?php if($id > 1){ ?> <li> <?php }?>
<?php
  for($i=1;$i <= $page;$i++){
?>
  <a href="?id=<?php echo $i ?>"><?php echo $i;?></a></li>
   <?php } ?>
<?php } else{$result = "currently there are no static for your faucet";}
?>   <div style="background-color:Mistyrose;color:red;">
		 <?php if(isset($result)){
                             echo $result; } ?>
     </div>
    
              <?php  endif; ?>
              </center>
     </div>
     </td>
     </tr>
     </table>
     </div>
    
<?php        include_once'../footer.php';
    ?>