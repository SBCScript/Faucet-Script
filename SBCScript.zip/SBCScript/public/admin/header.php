<?php 
	include_once'Session.php';
	include_once'../includes/Database.php';
	include_once'../includes/Utilities.php'; 
?>
<!DOCTYPE html>

<head> 
    </head>  
  <body> 
    <div width="auto" style="background-color:violet;padding:5px"> 
     <div style="text-align:center;background-color:comflowerblue;">
     <H1 style="color:white;font-family:verdana;font-size:200%;">Admin area</H1>
     <ul style="list-style-type: none;margin: 0;padding: 0;overflow: hidden;background-color: yellowgreen;">
     <li style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="index.php">Home</a>
     </li>
     <?php if(isset($_SESSION['username']) && $_SESSION['username'] == $admusr){ ?>
     <li style="float: left;><a style="float: left;"><a style="display: block;color: white;text-align: center;padding: 14px 16px;text-decoration: none;" href="logout.php">Logout</a>
     </li>
     <?php } ?>
     </ul>
    </div>