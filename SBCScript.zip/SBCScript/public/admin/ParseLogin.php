<?php 
    include_once'../includes/Database.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/

    include_once'../includes/Utilities.php';

    if(isset($_POST['lgBtn'])){

        //initialise the array 
        $form_errors = array();

        //Validate the form
        $required_fields = array('usr_adm','usr_pass');

        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

        if(empty($form_errors)){
            //Collect the form data
            $user = $_POST['usr_adm'];
            $pass = $_POST['usr_pass'];

            //check admin data and create session 
            if($admusr == $user AND $admpass == $pass){$_SESSION['username']= $user;
              }
            else{$result = "You have submit invalid data.please try again..";                    }                         
                  }
            else {
            if(count($form_errors) == 1) {
                $result = "There was 1 error in the form<br>";
            }
            else {
                $result = 'There were ' .count($form_errors). ' errors in the form<br>'; 
            }
        }         
   }
?>