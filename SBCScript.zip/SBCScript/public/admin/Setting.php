<?php 
    include_once'Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/

    include_once'../includes/Database.php';
    include_once'../includes/Utilities.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:white;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;"> 
                  <h2>Wellcone to your admin area</h2>  
     </div>
     </center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>
	<?php
                  elseif($_SESSION['username'] != $admusr):
        ?>	
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>		
		<?php else: ?>
<?php
		if(isset($_POST['SetBtn'])) {
		//Initilaise the array
		$form_errors = array();

		//form validation
		$required_fields = array('sitename', 'site_s_des','site_l_des','site_keyword','faucethub_api','currency','reward','refer_comisn','claimlimit','time_dif','shortlink_type','min_casho','google_pbk','google_sck');

		//check empty fields and merge into array
		$form_errors = array_merge($form_errors, check_empty_fields($required_fields));

		//Collect data from form
		$sitename = $_POST['sitename'];
		$site_s_des = $_POST['site_s_des'];
		$site_l_des = $_POST['site_l_des'];
		$site_keyword = $_POST['site_keyword'];
		$faucethub_api = $_POST['faucethub_api'];
		$currency = $_POST['currency'];
		$reward = $_POST['reward'];
		$refer_comisn = $_POST['refer_comisn'];
		$claimlimit = $_POST['claimlimit'];
		$time_dif = $_POST['time_dif'];
		$shortlink_type = $_POST['shortlink_type'];
		$min_casho = $_POST['min_casho'];
		$google_pbk = $_POST['google_pbk'];
		$google_sck = $_POST['google_sck'];

		if($currency=='Select currency for your faucet'){$resultw = "you must have to choose currency for your faucet";}
		elseif($shortlink_type=='Select shortlink type for faucet'){$resultw = "you must have to choose shortlimk type";}
		elseif(empty($form_errors)){
			try{
				//create sql update
				$sqlUpdate = "UPDATE Setting SET sitename =:sitename, S_description =:site_s_des, L_description =:site_l_des, Site_keyword =:site_keyword, api =:faucethub_api, currency =:currency, reward =:reward, refercomsn =:refer_comisn, claimlimit =:claimlimit, timediffernce =:time_dif, shortlink_type =:shortlink_type,min_cashout = :min_casho, Google_pbk =:google_pbk, Google_sck =:google_sck";

				//Sanitise 
				$statement = $db->prepare($sqlUpdate);

				//update 
				$statement->execute(array(':sitename' => $sitename, ':site_s_des' => $site_s_des, ':site_l_des' => $site_l_des, ':site_keyword' => $site_keyword, ':faucethub_api' => $faucethub_api, ':currency' => $currency, ':reward' => $reward, ':refer_comisn' => $refer_comisn, ':claimlimit' => $claimlimit, ':time_dif' => $time_dif, ':shortlink_type' => $shortlink_type,':min_casho' => $min_casho, ':google_pbk' => $google_pbk, ':google_sck' => $google_sck));

				//Check if one new row was created
				if($statement->rowCount() == 1){
					$results = 'update setting successful';
						
				}
				else {
					$resultw = 'Nothing change in setting';
						
				}
			}
			catch (PDOException $ex) {
				$resultw = "An error occured in: " .$ex->getMessage();
			}
		}
		else {
			if(count($form_errors) == 1) {
				$resultw = "There was 1 error in the form <br>";
			}
			else {
				$resultw = "There were " .count($form_errors). " errors in the form <br>";
			}
		}
	}
	$sqlQuery = "SELECT * FROM Setting";
            $statement = $db->prepare($sqlQuery);
            $statement->execute(array());

         //fetch data from DB & compare it with inputted data 
            while($row = $statement->fetch()){
                $sitenm = $row['sitename'];
                $sitesdes = $row['S_description'];
                $siteldes = $row['L_description'];
                $sitekeyw = $row['Site_keyword'];
                $fauh_api = $row['api'];
                $currency = $row['currency'];
                $reward = $row['reward'];
                $refcomsn = $row['refercomsn'];
                $claimlimit = $row['claimlimit'];
                $timedif = $row['timediffernce'];
                $shortlink_t = $row['shortlink_type'];
                $min_casho = $row['min_cashout'];
                $google_pk = $row['Google_pbk'];
                $google_sk = $row['Google_sck'];
                }
    
?>
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as admin of this site</h3></ul>
<?php		if(isset($resultw)){ ?>
		<ul style='background-color:Mistyrose;color:red;'>
                  <p><?php echo $resultw ; ?></p></ul>
<?php } ?>                  
<?php		if(isset($results)){ ?>
		<ul style='background-color:palegreen;color:green;'>
                  <p><?php echo $results ; ?></p></ul>
<?php } ?>                  
		
		<br><h3>Mange Setting of faucet site</h3>
		<h3> Update Setting for your site</h3>
            <form action="" method="POST">
                  <input type="text" name="sitename" autocomplete="off" placeholder="site name" style="width:200px;height:25px;" value ="<?php echo $sitenm ; ?>" required>
                  <input type="text" name="site_s_des" autocomplete="off" placeholder="site short description " style="width:200px;height:25px;" value ="<?php echo $sitesdes ; ?>" required>
                  <textarea name="site_l_des" rows="4" cols="50" placeholder="site long description" required><?php echo $siteldes; ?></textarea>
                  <input type="text" name="site_keyword" autocomplete="off" placeholder="site keyword for search engine" style="width:200px;height:25px;" value ="<?php echo $sitekeyw ; ?>" required>
                  <input type="text" name="faucethub_api" autocomplete="off" placeholder="faucerhub api key " style="width:200px;height:25px;" value ="<?php echo $fauh_api ; ?>" required>
                  <select name="currency" id="option" style="width:200px;height:25px;" required>
                  <option >Select currency for your faucet</option>
                  <option value="BTC">BTC</option>
                  <option value="ETH">ETH</option>
                  <option value="XMR">XMR</option>
                  <option value="LTC">LTC</option>
                  <option value="DOGE">DOGE</option>
                  <option value="BCH">BCH</option>
                  <option value="ZEC">ZEC</option>
                  <option value="DGB">DGB</option>
                  <option value="BTX">BTX</option>
                  <option value="BLK">BLK</option>
                  <option value="DASH">DASH</option>
                  <option value="PPC">PPC</option>
                  <option value="XPM">XPM</option>
                  <option value="POT">POT</option>
                  </select>
                  <input type="number" name="reward" autocomplete="off" placeholder="each claim reward in satoshi" min="1" step="1" style="width:200px;height:25px;" value ="<?php echo $reward ; ?>" required>
                  <input type="number" name="refer_comisn" autocomplete="off" placeholder="refer commission in satoshi unit" min="0" step="1" style="width:200px;height:25px;" value ="<?php echo $refcomsn ; ?>" required>
                  <input type="number" name="claimlimit" autocomplete="off" placeholder="number of claim in 24h for single user" min="1" step="1" style="width:200px;height:25px;" value ="<?php echo $claimlimit ; ?>" required>
                  <input type="number" name="time_dif" autocomplete="off" placeholder="time dif in min between two respective claim" min="1" step="1" style="width:200px;height:25px;" value ="<?php echo $timedif ; ?>" required>
                  <select name="shortlink_type" id="option" style="width:200px;height:25px;" required>
                  <option >Select shortlink type for faucet</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  /select>
                  <input type="number" name="min_casho" autocomplete="off" placeholder="minimum cashout" min="1" step="1" style="width:200px;height:25px;" value ="<?php echo $min_casho ; ?>" required>
                  <input type="text" name="google_pbk" autocomplete="off" placeholder="Google recapcha public key" style="width:200px;height:25px;" value ="<?php echo $google_pk ; ?>" required>
                  <input type="text" name="google_sck" value ="<?php echo $google_sk ; ?>" autocomplete="off" placeholder ="Google recapcha secret key" style="width:200px;height:25px;" required>
                  <br><br>
                  <p><input type="submit" style="width:100px;height:50px;background-color:blue;color:white;" name="SetBtn" value="update setting">
                  </p>
		</form>
              <?php  endif; ?>
              </center>
     </div>
     </td>
     </tr>
     </table>
     </div>
    
<?php        include_once'../footer.php';
    ?>