<?php 
    include_once'Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/

    include_once'../includes/Database.php';
    include_once'../includes/Utilities.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:white;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;"> 
                  <h2>Wellcone to your admin area</h2>  
     </div>
     </center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>
	<?php
                  elseif($_SESSION['username'] != $admusr):
        ?>	
                  <ul style='background-color:mistyrose;color:red;'>
                  <h3>Your logged in session expired.Go to <a href="index.php">login</a></h3></ul>		
		
<?php else: ?>
<?php
	if(isset($_POST['SladdBtn'])){
	//Initialise the array to store messages from form
        $form_errors = array();

        //form validation
        $required_fields = array('short_url', 'short_key','prt');

        //call the function to check empty field and merge the return data into array
        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

        //Collect form data and store in vars
        $short_url = $_POST['short_url'];
        $short_key = $_POST['short_key'];
        $short_prt = $_POST['prt'];
        if($short_prt =="Priority for this shortlink"){$resultw = "Please select priority option for this new shortlink";}
        elseif(checkDuplicateEntries("Shortlink_selected", "shortlink", $short_url, $db)){
            $resultw = "shortlink is already exit in database table";
        }
        //check if error array is empty, if yes process and insert data
        elseif (empty($form_errors)){
           try{
                //Create SQL insert 
                $sqlInsert = "INSERT INTO Shortlink_selected (shortlink, api, prt)
                                VALUES (:short_url, :short_key,:prt)";

                //sanitise data
                $statement = $db->prepare($sqlInsert);

                //Add data into the db 
                $statement->execute(array(':short_url' => $short_url, ':short_key' => $short_key, ':prt' => $short_prt));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){

                    //call sweetalert 
                    $results = " Shortlink data successfully add to database table";
                }
            }
            catch(PDOException $ex) {
                $resultw = "An error has occurred " .$ex->getMessage();
            }
        }
        else {
            if(count($form_errors) == 1){
                $resultw = "There was 1 error in the form<br>";
            }
            else {
                $resultw = "There were " .count($form_errors). " errors in the form<br>";
            }
        }
       }
       if(isset($_POST['delBtn'])){
	//Initialise the array to store messages from form
        $form_errors = array();

        //form validation
        $required_fields = array('short_url');

        //call the function to check empty field and merge the return data into array
        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

        //Collect form data and store in vars
        $short_url = $_POST['short_url'];
        
        //check if error array is empty, if yes process and insert data
       if(empty($form_errors)){
           try{
                //Create SQL insert 
                $sqldel = "DELETE FROM Shortlink_selected WHERE shortlink = :short_url";

                //sanitise data
                $statement = $db->prepare($sqldel);

                //Add data into the db 
                $statement->execute(array(':short_url' => $short_url));

                //Check if one new row has been created 
                if($statement->rowCount() == 1){

                    //call sweetalert 
                    $results = " Record of ".$short_url."  deleted from database table";    
                }
            }
            catch(PDOException $ex) {
                $resultw = "An error has occurred " .$ex->getMessage();
            }
        }
        else {
            if(count($form_errors) == 1){
                $resultw = "There was 1 error in the form<br>";
            }
            else {
                $resultw = "There were " .count($form_errors). " errors in the form<br>";
            }
        }
       }
?>      
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as admin of this site</h3></ul>
<?php		if(isset($resultw)){ ?>
		<ul style='background-color:Mistyrose;color:red;'>
                  <p><?php echo $resultw ; ?></p></ul>
<?php } ?>                  
<?php		if(isset($results)){ ?>
		<ul style='background-color:palegreen;color:green;'>
                  <p><?php echo $results ; ?></p></ul>
<?php } ?>                  

		<br><h3>Mange Short links</h3>
<?php	$start=0;
        $limit=30;
        if(isset($_GET['id'])){
        $id=$_GET['id'] ; 
        $start=($id-1)*$limit;}
        else{$id=1;}
        $sqlQuery1 = "SELECT * FROM Shortlink_selected ";
            $statement1 = $db->prepare($sqlQuery1);
            $statement1->execute(array());
            if($statement1->rowcount()>0){
            $total = $statement1->rowcount();
            $page=ceil($total/$limit);
            
            $sqlQuery2 = "SELECT * FROM Shortlink_selected limit $start, $limit ";
            $statement2 = $db->prepare($sqlQuery2);
            $statement2->execute(array()); ?>
            <div class="container">
            <h4>Your short links service provider with api from database</h4>
            <center><table class="table table-bordered">
            <thead>
            <tr>
            <th>shortlink</th>
            <th>api</th>
            <th>priority</th>
            <th>delete</th>
            </tr>
            </thead>
            <tbody>
<?php
            while($row1=$statement2->fetch()){?>
            <tr>
            <td><?= $row1['0']?></td>
            <td><?= $row1['1']?></td>
            <td><?= $row1['2']?></td>
            <td><form method="POST" action="">									
        <input type="hidden" name="short_url" value="<?php echo $row1['0'] ; ?>">
        <p><input type="submit" style="width:80px;height:50px;background-color:blue;color:white;" name="delBtn" value="Delete">
        </p></form></td>
            </tr>   
<?php } ?>
            </tbody>
            </table></center>
            <ul class="pagination">
<?php       if($id > 1){ ?> <li><a href="?id=<?php echo $id; ?>-1">Previous</a></li><?php }?>
<?php
            for($i=1;$i <= $page;$i++){
?>
            <li><a href="?id=<?php echo $i ?>"><?php echo $i;?></a></li>
<?php   } ?>
            </div>
<?php       if($id!=$page){ $result = "no result found ";} }
            else{$result = "Currently you have not added any shortlink service to your database table.so shortlink service uses of script author";}
?>
            <div style="background-color: MistyRose;color: red;">
<?php       if(isset($result)){
             echo $result; } ?>
            </div>
            <br><br>
            <H3> Add Short link Service (add at least 5 for better result)</H3>
            <form action="" method="POST">
                  <input type="text" name="short_url" autocomplete="off" placeholder="shortlink site URL without http(s)://" style="width:200px;height:25px;" required>
                  <input type="text" name="short_key" autocomplete="off" placeholder ="api key" style="width:200px;height:25px;" required>
                  <select name="prt" id="option" style="width:200px;height:25px;" required>
                  <option >Priority for this shortlink</option>
                  <option value="Yes">Yes</option>
                  <option value="No">No</option>
                  </select>
                  <br><br>
                  <p><input type="submit" style="width:80px;height:50px;background-color:blue;color:white;" name="SladdBtn" value="Add now">
                  </p>
		</form>
<?php  endif; ?>
            </center>
            </div>
            </td>
            </tr>
            </table>
            </div>
    
<?php        include_once'../footer.php';
    ?>