<?php 
    include_once'config/Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    $page_title = 'Home';
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';
    include_once'solvemedialib.php';
    include_once'ParseLogin.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:yellow;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toplad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;">
     <?php echo $adpop ; ?>
                  <h2 style="color:purple;"><?php echo $sitesdes ; ?></h2>  
     </div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toprad ; ?></center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlelad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!empty($_GET['r'])){$_SESSION['refer'] = $_GET['r'];}
	          else{$_SESSION['refer'] = '0';}
	          include_once'checkip.php';

	          if($faucetstate == '0'){ ?>
	          <div style='background-color:MistyRose;color:red;'>
                  <?php echo "Currently the faucet is inactive state.please check later for claim free reward"; ?>
                  </div><?php } elseif(isset($reslutip) && $reslutip == 'Fail'){ ?>
                  <div style='background-color:MistyRose;color:red;'>
                  <?php echo "System show that your IP address(".$user_ip.") is belong to the list of Proxy,VPN,TOR or bad IP (Black IP list) , which are restricted by this faucet site.If you think your IP is still against these IPs list and its happened exidently.Please contact with your IP for removed from black IPs list."; ?>
                  </div><?php } else { ?>
                  <?php if(isset($_GET['cp'])){
                  if($_GET['cp'] =='solvemedia' && $solve_media_captcha =='true'){
                  $cp_to_verify = 'solvemedia';
                  $div2 = "<div id='solvemedia'>" ;
                  $div1 = "<div id='google' style='display:none'>"; 
                  $div3 = "<div id='raincaptcha' style='display:none'>"; 
                  $div4 = "<div id='coinhive' style='display:none'>"; 
                  }
                  elseif($_GET['cp'] =='raincaptcha' && $rain_captcha =='true'){
                  $cp_to_verify = 'raincaptcha';
                  $div3 = "<div id='raincaptcha'>" ;
                  $div1 = "<div id='google' style='display:none'>"; 
                  $div2 = "<div id='solvemedia' style='display:none'>"; 
                  $div4 = "<div id='coinhive' style='display:none'>"; 
                  }
                  elseif($_GET['cp'] =='coinhive' && $coinhive_captcha =='true'){
                  $cp_to_verify = 'coinhive';
                  $div4 = "<div id='coinhive'>" ;
                  $div1 = "<div id='google' style='display:none'>"; 
                  $div2 = "<div id='solvemedia' style='display:none'>"; 
                  $div3 = "<div id='raincaptcha' style='display:none'>"; 
                  }
                  else{
                  $div1 = "<div id='google'>" ;
                  $div2 = "<div id='solvemedia' style='display:none'>"; 
                  $div3 = "<div id='raincaptcha' style='display:none'>"; 
                  $div4 = "<div id='coinhive' style='display:none'>"; 
                  } }
                  else{
                  $div1 = "<div id='google'>" ;
                  $div2 = "<div id='solvemedia' style='display:none'>"; 
                  $div3 = "<div id='raincaptcha' style='display:none'>"; 
                  $div4 = "<div id='coinhive' style='display:none'>"; 
                  } ?>
                  <?php 
                  if(!isset($_SESSION['username'])): ?>
                  
                  <h2>Register or Login using Faucethub <?php echo $currency ; ?> wallet address</h2>
                  <br>
                  <ul style='background-color:MistyRose;color:red;'>
                  <?php if(isset($result)){ echo $result;} ?>
                  </ul>
                  <br>
                  <form action="" method="POST">
                  <input type="text" name="usr_wlt" autocomplete="on" placeholder="Your faucethub <?php echo $currency ; ?> wallet address" style="width:506px;height:38px;" required>
                  <input type="hidden" name="ref" value="<?php echo $_SESSION['refer']; ?>">
                  <input type="hidden" name="cp" value="<?php if(isset($cp_to_verify)){echo $cp_to_verify ;}else {echo "none" ;} ?>">
                  <br><br>
                  <style>
                  .text-xs-center { text-align: center; }
                  .g-recaptcha { display: inline-block; }
                  </style><?php echo $div1 ; ?>
                  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                  <div class="text-xs-center">
                  <div class="g-recaptcha" data-sitekey="<?php echo $google_pk ; ?>"></div></div>
                  <br>
                  <center><table><centre><tr><th><?php if($solve_media_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href='?cp=solvemedia'>  Solvemedia captcha 
 </a></th> <th>OR</th> <th><?php } if($rain_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href='?cp=raincaptcha'>  Rain captcha  </a></th> <th>OR</th> <th><?php } if($coinhive_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href='?cp=coinhive'>  Coinhive captcha  </a><?php } ?>
                  </th></tr></centre></table></center></div>
                  <?php echo $div2 ;?>
                  <div class="text-xs-center"><center>
                  <?php echo solvemedia_get_html($SM_c_key); ?></center>
                  <br>
                  <center><table><centre><tr><th><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp='>  Google recaptcha 
 </a></th> <th>OR</th> <th><?php if($rain_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp=raincaptcha'>  Rain captcha  </a></th> <th>OR</th> <th><?php } if($coinhive_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp=coinhive'>  Coinhive captcha  </a><?php } ?>
                  </th></tr></centre></table></center></div></div>
                  <?php echo $div3 ; ?>
                  <script src="https://raincaptcha.com/base.js" type="application/javascript"></script>
                  <div id="rain-captcha" data-key="<?php echo $RC_p_key ; ?>"></div>
                  <br>
                  <center><table><centre><tr><th><?php if($solve_media_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp=solvemedia'>  Solvemedia captcha 
 </a></th> <th>OR</th> <th><?php } ?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp='>  Google recaptcha 
 </a></th> <th>OR</th> <th><?php if($coinhive_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp=coinhive'>  Coinhive captcha  </a><?php } ?>
                  </th></tr></centre></table></center></div>
                 <?php echo $div4 ; ?>
                 <script src="https://authedmine.com/lib/captcha.min.js" async></script>
    <div class="coinhive-captcha" data-hashes="1024" data-key="<?php echo $CC_p_key ; ?>">
        <em>Loading Captcha...<br>
        If it doesnot load, please disable Adblock!</em>
    </div>
                  <br>
                  <center><table><centre><tr><th><?php if($solve_media_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp=solvemedia'>  Solvemedia captcha 
 </a></th> <th>OR</th> <th><?php } if($rain_captcha =='true'){?><a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp=raincaptcha'>  Rain captcha  </a></th> <th>OR</th> <th><?php } ?> <a style="display: block;background-color:orange;color: white;text-align: center;width: 100px;text-decoration: none;" href = '?cp='>  Google recaptcha 
 </a>
                  </th></tr></centre></table></center></div>
                  <p><input type="submit" style="width:300px;height:30px;background-color:blue;color:white;" name="lg_or_rg" value="Submit">
                  </p>
		</form>
		<?php else: ?>
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></h3>
                  <h4> Your current account balance is <?php echo $ac_bl_am ; ?> satoshis of <?php echo $currency ; ?>.You can withdraw at minimum <?php echo $min_casho ; ?> satoshis</h4></ul>
		<br><br>
<?php           $user = $_SESSION['username'];
                $S_Verify = 1;
                $Paid = 1;
                $S_Verify1 = 0;
                $Paid1 = 0;
                $date = date('Y-m-d H:i:s');
                $datebefore = date('Y-m-d H:i:s', strtotime('-24 hour'));
                //check for missing shortlink 
                $qcheckslv = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify1 AND Paid =:Paid1";
                $statement = $db->prepare($qcheckslv);
                $statement->execute(array(':user' => $user ,':S_Verify1' => $S_Verify1,':Paid1' => $Paid1 ));
                if($statement->rowcount()>0){
                $result = "Short link verification failed.Please try again<br>";
                if($shortlink_forse =='false'){
                $resultdc = "<p>OR</p><a style='display: block;background-color:orange;color: white;text-align: center; text-decoration: none;' href='direct_claim.php'>Claim without shortlink(s) verify for some low reward</a>";}
                if($shortlink_t == 1){
                $result1 =  "<br><br>
                <div style='text-align:center'>
                <form action='s_l.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='again verify' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}
                else{
                $result1 =  "<br><br>
                <div style='text-align:center'>
                <form action='s_l2.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='again verify' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}}
                else{
                //check for missing claim reward
                $qcheckcp = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify AND Paid =:Paid1";
                $statement = $db->prepare($qcheckcp);
                $statement->execute(array(':user' => $user , ':S_Verify' => $S_Verify,':Paid1' => $Paid1 ));
                if($statement->rowcount()>0){
                $result = "You have pending one claim reward.please click the claim now button and go to for claim.";
                $result1 = "<br><br>
                <div style='text-align:center'>
                <form action='payout.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='claim now' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}
                else{
                //check for claim limit approach for an address
                $qcheckcl = "SELECT * FROM Claimlog WHERE address =:user AND time > :time2 AND time < :time1 AND S_Verify = :S_Verify AND Paid =:Paid";
                $statement = $db->prepare($qcheckcl);
                $statement->execute(array(':user' => $user ,':time2' => $datebefore ,':time1' => $date , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
                if($statement->rowcount()>= $claimlimit){
                $result = "You have reached the limit of maximum claim for 24 hours.Please claim again later.";
                }
                else{
                //check for claim limit approach for an ip
                $qcheckclip = "SELECT * FROM Claimlog WHERE ip =:user_ip AND time > :time2 AND time < :time1 AND S_Verify = :S_Verify AND Paid =:Paid";
                $statement = $db->prepare($qcheckclip);
                $statement->execute(array(':user_ip' => $user_ip ,':time2' => $datebefore ,':time1' => $date , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
                if($statement->rowcount()>= $claimlimit){
                $result = "You have reached the limit of maximum claim for 24 hours.Please claim again later.";
                }
                else{
                //check for time for next claim
                $qchecktime = "SELECT * FROM Claimlog WHERE address =:user AND S_Verify = :S_Verify AND Paid =:Paid";
                $statement = $db->prepare($qchecktime);
                $statement->execute(array(':user' => $user , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
                if($statement->rowcount()>0){
                while($row = $statement->fetch()){
                $last_claim_time = $row['time'];}}
                else{ $last_claim_time = '0000-00-00 00:00:00';}
                $timestamp = date('Y-m-d H:i:s');
                $claimtime = strtotime($timestamp) - strtotime($last_claim_time) ;
                $claimtime = round(abs($claimtime)/60,2) ;
                if($claimtime < $timedif ){
                $againclaimtime = $timedif - $claimtime ;
                $result ="You have to wait at least ".$againclaimtime." min For claim again.<br>";
                }   
                else {
                //check IP for scam claim
                $qcheckip = "SELECT * FROM Claimlog WHERE ip =:user_ip AND S_Verify = :S_Verify AND Paid =:Paid";
                $statement = $db->prepare($qcheckip);
                $statement->execute(array(':user_ip' => $user_ip , ':S_Verify' => $S_Verify,':Paid' => $Paid ));
                if($statement->rowcount()>0){
                while($row = $statement->fetch()){
                $iplast_claim_time = $row['time'];}
                $ipclaimtime = strtotime($timestamp) - strtotime($iplast_claim_time) ;
                $ipclaimtime = round(abs($ipclaimtime)/60,2) ;
                if($ipclaimtime < $timedif ){
                $ipagainclaimtime = $timedif - $ipclaimtime ;
                $result = "You have to wait at least $ipagainclaimtime min For claim again.<br>";
                }   
                else { 
                $result2 = "Please verify short link(s) for claim free reward";
                if($shortlink_forse =='false'){
                $resultdc = "<p>OR</p><a style='display: block;background-color:orange;color: white;text-align: center; text-decoration: none;' href='direct_claim.php'>Claim without shortlink(s) verify for some low reward</a>";}
                if($shortlink_t == 1){
                $result1 = "<br><br> 
                <div style='text-align:center'>
                <form action='s_l.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='Go to verify shorlink' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}
                else{
                $result1 =  "<br><br>
                <div style='text-align:center'>
                <form action='s_l2.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='Go to verify shorlink' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}}}
                else{
                //show short link button
                if($shortlink_forse =='false'){
                $resultdc = "<p>OR</p><a style='display: block;background-color:orange;color: white;text-align: center; text-decoration: none;' href='direct_claim.php'>Claim without shortlink(s) verify for some low reward</a>";}
                $result2 = "Please verify short link(s) for claim free reward";
                if($shortlink_t == 1){
                $result1 =  "<br><br>
                <div style='text-align:center'>
                <form action='s_l.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='Go to verify shorlink' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}
                else{
                $result1 =  "<br><br>
                <div style='text-align:center'>
                <form action='s_l2.php' method='POST'><div>
                <input name='SLVBtn' type='submit' value='Go to verify shorlink' style='width:250px;height:40px;background-color:blue;color:white;'>                                   
                </div> </form> </div>   ";}
                } } } } } } ?>

              <div style='background-color:LightCyan;color:mediumpurple;'>
              <?php if(isset($result2)){echo $result2;} ?>
              </div>
              <div style='background-color:MistyRose;color:red;'>
              <?php if(isset($result)){echo $result;} ?>
              </div>
              <br><br>
              <div>
              <?php if(isset($result1)){echo $result1;} ?></div>
              <div>
              <?php if(isset($resultdc)){echo $resultdc;} ?></div>
              <?php  endif; ?>
              <?php  } ?>
              </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlerad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
     <div style="text-align:center;background-color:white;color:green;padding:10px;">
     <p>Referral link http://<?php echo $site ; ?>/?r=<?php if(isset($_SESSION['username'])){echo $_SESSION['username'] ;} else{echo"Your_account_address";} ?></p>
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomlad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:650px;hight:600px;">
     <center>
     <div style="background-color:aquamarine;color:green;padding:20px;">     <?php		 
// recent payout
 $S_Verify = 1;
 $Paid = 1;
 $qrecent = "SELECT address, time, reward FROM Claimlog WHERE S_Verify = :S_Verify AND Paid = :Paid  ORDER BY id DESC LIMIT 10";
    $statement = $db->prepare($qrecent);
    $statement->execute(array(':S_Verify' => $S_Verify,':Paid' => $Paid ));
    if($statement->rowCount()>0) {
        echo'<h3>Recent Payouts</h3><table class="recent-payouts" border="1"><tr><th class="list-left" width="50%" >Date</th><th class="list-center" width="100%">Address</th><th class="list-right" width="50%">Reward</th></tr>';
        while($rowrec = $statement->fetch()){
            echo '<td class="list-left"><center>'.$rowrec['time'].'</center></td>';
            echo '<td class="list-center"><center>'.$rowrec['address'].'</center></td>';
            echo '<td class="list-right"><center>'.$rowrec['reward'].'</center></td>';
            echo '<tr>';
        }
        echo '</table>'; }
?>
</div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomrad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
<?php        include_once'footer.php';
    ?>