<?php 
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'solvemedialib.php';
    include_once'Setting.php';

    if(isset($_POST['lg_or_rg'])){
    if($_POST['cp'] =='solvemedia' && $solve_media_captcha == 'true'){
    $solvemedia_response = solvemedia_check_answer($SM_v_key,
					$_SERVER["REMOTE_ADDR"],
					$_POST["adcopy_challenge"],
					$_POST["adcopy_response"],
					$SM_H_key);
if (!$solvemedia_response->is_valid) {
	$captcha_verified = 'false';
	}
else {
	$captcha_verified = 'true';
}
    }
    elseif($_POST['cp'] == 'raincaptcha' && $rain_captcha == 'true'){
    $client = new SoapClient('https://raincaptcha.com/captcha.wsdl');
    $response = $client->send($RC_s_key, $_POST['rain-captcha-response'], $_SERVER['REMOTE_ADDR']);

if ($response->status === 1) {
    $captcha_verified = 'true';
} else {
    $captcha_verified = 'false';
}
    }
    elseif($_POST['cp'] =='coinhive' && $coinhive_captcha == 'true'){
            $post_data = ['secret' => $CC_s_key,'token' => $_POST['coinhive-captcha-token'],'hashes' => 1024];
            $post_context = stream_context_create(['http' => ['header'  => "Content-type: application/x-www-form-urlencoded\r\n",'method'  => 'POST','content' => http_build_query($post_data)]]);
            $url_res = 'https://api.coinhive.com/token/verify';
            $response = json_decode(file_get_contents($url_res, false, $post_context));
            if ($response && $response->success) {
            $captcha_verified = 'true';}
            else{$captcha_verified = 'false';} }
    else{
        $resp = $_POST['g-recaptcha-response'];
	$recaptcha_private = $google_sk;
	$ip = $user_ip;
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,
			"secret=$recaptcha_private&response=$resp&ip=$ip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec ($ch);
	curl_close ($ch);
	
	$json = json_decode($server_output);
	
	if (!$json->hostname){
		$captcha_verified = "false";
	} else {  
	     $captcha_verified = 'true';
	} }
	if($captcha_verified == 'true'){
	$form_errors = array();

        //Validate the form
        $required_fields = array('usr_wlt');

        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

        if(empty($form_errors)){
            //Collect the form data
            $user = $_POST['usr_wlt'];
            $ref_add = $_POST['ref'];

            //check if user exists in the db 
            $sqlQuery = "SELECT * FROM Claim_Addresses WHERE address = :user ";
            $statement = $db->prepare($sqlQuery);
            $statement->execute(array(':user' => $user));
              if($statement->rowcount() > 0){
         //fetch data from DB & compare it with inputted data 
                 while($row = $statement->fetch()){
                  $user1 = $row['address'];
                                                  }
                 if($user1 == $user){$_SESSION['username']= $user;
         }               }
               else{$sqlQueryref = "SELECT * FROM Claim_Addresses WHERE address = :refer AND Currency =:currency ";
                  $statement = $db->prepare($sqlQueryref);
                  $statement->execute(array(':refer' => $ref_add,':currency'=> $currency));
                  if($statement->rowcount() > 0){
                  $ch = curl_init();
		        curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/checkaddress");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$fauh_api&address=$user&currency=$currency");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
	
			$checkwref = json_decode($server_output,true);
			if($checkwref['status'] == "200"){
			
				//Create SQL insert 
                           $sqlInsertwref = "INSERT INTO Claim_Addresses (address, ref_add, Currency)
                                VALUES (:address, :ref_add,:currency)";

                          //sanitise data
                           $statement = $db->prepare($sqlInsertwref);
                          //Add data into the db 
                           $statement->execute(array(':address' => $user, ':ref_add' => $ref_add, ':currency' =>$currency));
                          //Check if one new row has been created 
                           if($statement->rowCount() == 1){
	$_SESSION['username']= $user;
                                                 
 	                                                  }
 	                    else {$result = "Sorry! we can't verify your Wallet address";
			         }
 	                                                  }
	                 else {$result = $checkwref['message'];                    }                         }
                  else{
                       $ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/checkaddress");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$fauh_api&address=$user&currency=$currency");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
	
			$check = json_decode($server_output,true);
			if($check['status'] == "200"){
			
		         //Create SQL insert 
                           $sqlInsert = "INSERT INTO Claim_Addresses (address, ref_add, Currency)
                                VALUES (:address, :ref_add, :currency)";
                         //sanitise data
                           $statement = $db->prepare($sqlInsert);
                         //Add data into the db 
                           $statement->execute(array(':address' => $user, ':ref_add' => $ref_add, ':currency' =>$currency));

                         //Check if one new row has been created 
                           if($statement->rowCount() == 1){
	$_SESSION['username']= $user;
                           
 	                                                  } 
 	                    else {$result = "Sorry! we can't verify your Wallet asdress";
	                         }
 	                                             }
	                 else{$result = $check['message'];
		             } 
		      } 
		    } 
		                 }
		                
   } 
   else{ $result = 'Captcha verification failed.please try again'; }
  }
  if(isset($_SESSION['username'])){
                  $user = $_SESSION['username'] ;
                $qblackadrcheck = "SELECT * FROM Black_address WHERE address =:check_black ";
 $statement = $db->prepare($qblackadrcheck);
            $statement->execute(array(':check_black' => $user ));
            if($statement->rowcount()>0){
            //Signout finction
	signout();


	//Do not delete!!!
	//This will be moved shortly 

	
	/*//Unset all of the session vars
	$_SESSION = array(); 

	//This will kill the session & destroy any cookies
	if (ini_get("session.use_cookies")){
		$params = session_get_cookie_params();
		setcookie(session_name(), '', time() -42000,
			$params["path"], $params["domain"],
			$params["secure"], $params["httponly"]
		);
	}

	//Finally destroy the session
	session_destroy();

	redirectTo('index');*/
            }  
                  
                $qblsel = "SELECT * FROM Claim_Addresses WHERE address =:user ";
                $statement = $db->prepare($qblsel);
                $statement->execute(array(':user' => $user ));
                if($statement->rowcount()>0){
                while($row2 = $statement->fetch()){
                $ac_bl_am = $row2['balance'];}
                  } 
                 }
?>