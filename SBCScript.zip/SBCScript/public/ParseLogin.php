<?php
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';

    if(isset($_POST['lg_or_rg'])){
        $resp = $_POST['g-recaptcha-response'];
	$recaptcha_private = $google_sk;
	$ip = $user_ip;
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,
			"secret=$recaptcha_private&response=$resp&ip=$ip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec ($ch);
	curl_close ($ch);
	
	$json = json_decode($server_output);
	
	if (!$json->hostname){
		$result = "Captcha verification failed.please try again";
	} else {  
	// success

        //initialise the array 
        $form_errors = array();

        //Validate the form
        $required_fields = array('usr_wlt');

        $form_errors = array_merge($form_errors, check_empty_fields($required_fields));

        if(empty($form_errors)){
            //Collect the form data
            $user = $_POST['usr_wlt'];
            $ref_add = $_POST['ref'];

            //check if user exists in the db 
            $sqlQuery = "SELECT * FROM Claim_Addresses WHERE address = :user ";
            $statement = $db->prepare($sqlQuery);
            $statement->execute(array(':user' => $user));
              if($statement->rowcount() > 0){
         //fetch data from DB & compare it with inputted data 
                 while($row = $statement->fetch()){
                  $user1 = $row['address'];
                                                  }
                 if($user1 == $user){$_SESSION['username']= $user;
         }               }
               else{$sqlQueryref = "SELECT * FROM Claim_Addresses WHERE address = :refer AND Currency =:currency ";
                  $statement = $db->prepare($sqlQueryref);
                  $statement->execute(array(':refer' => $ref_add,':currency'=> $currency));
                  if($statement->rowcount() > 0){
                  $ch = curl_init();
		        curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/checkaddress");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$fauh_api&address=$user&currency=$currency");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
	
			$checkwref = json_decode($server_output,true);
			if($checkwref['status'] == "200"){
			
				//Create SQL insert 
                           $sqlInsertwref = "INSERT INTO Claim_Addresses (address, ref_add, Currency)
                                VALUES (:address, :ref_add,:currency)";

                          //sanitise data
                           $statement = $db->prepare($sqlInsertwref);
                          //Add data into the db 
                           $statement->execute(array(':address' => $user, ':ref_add' => $ref_add, ':currency' =>$currency));
                          //Check if one new row has been created 
                           if($statement->rowCount() == 1){
	$_SESSION['username']= $user;
                                                 
 	                                                  }
 	                    else {$result = "Sorry! we can't verify your Wallet address";
			         }
 	                                                  }
	                 else {$result = $checkwref['message'];                    }                         }
                  else{
                       $ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/checkaddress");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$fauh_api&address=$user&currency=$currency");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
	
			$check = json_decode($server_output,true);
			if($check['status'] == "200"){
			
		         //Create SQL insert 
                           $sqlInsert = "INSERT INTO Claim_Addresses (address, ref_add, Currency)
                                VALUES (:address, :ref_add, :currency)";
                         //sanitise data
                           $statement = $db->prepare($sqlInsert);
                         //Add data into the db 
                           $statement->execute(array(':address' => $user, ':ref_add' => $ref_add, ':currency' =>$currency));

                         //Check if one new row has been created 
                           if($statement->rowCount() == 1){
	$_SESSION['username']= $user;
                           
 	                                                  } 
 	                    else {$result = "Sorry! we can't verify your Wallet asdress";
	                         }
 	                                             }
	                 else{$result = $check['message'];
		             } 
		      } 
		    } 
		                 }
		                
   } 
  }
  if(isset($_SESSION['username'])){
                  $user = $_SESSION['username'] ;
                $qblackadrcheck = "SELECT * FROM Black_address WHERE address =:check_black ";
 $statement = $db->prepare($qblackadrcheck);
            $statement->execute(array(':check_black' => $user ));
            if($statement->rowcount()>0){
            //Signout finction
	signout();


	//Do not delete!!!
	//This will be moved shortly 

	
	/*//Unset all of the session vars
	$_SESSION = array(); 

	//This will kill the session & destroy any cookies
	if (ini_get("session.use_cookies")){
		$params = session_get_cookie_params();
		setcookie(session_name(), '', time() -42000,
			$params["path"], $params["domain"],
			$params["secure"], $params["httponly"]
		);
	}

	//Finally destroy the session
	session_destroy();

	redirectTo('index');*/
            }  
                  
                $qblsel = "SELECT * FROM Claim_Addresses WHERE address =:user ";
                $statement = $db->prepare($qblsel);
                $statement->execute(array(':user' => $user ));
                if($statement->rowcount()>0){
                while($row2 = $statement->fetch()){
                $ac_bl_am = $row2['balance'];}
                  } }
?>