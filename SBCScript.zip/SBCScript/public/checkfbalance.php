<?php
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';    
    
if($checkbltime == 0){$checkbltimep = '0000-00-00 00:00:00';}
                else{$checkbltimep = $checkbltime ;}
                $currentt = date('Y-m-d H:i:s');
  $difbltime = strtotime($currentt) - strtotime($checkbltimep) ;
  $difbltime = $difbltime/60 ;
  
  if($difbltime > 5 ){
   $ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/balance");
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,
				"api_key=$fauh_api&currency=$currency");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$blserver_output = curl_exec($ch);
		curl_close ($ch);
	        $blcheck = json_decode($blserver_output,true);
		if($blcheck['status'] == "200"){$blbalance = $blcheck['balance'];
		$blqupdate = "UPDATE Setting SET balance =:blbalance, check_balance_time = :curtime";
	                $statement = $db->prepare($blqupdate);
                        $statement->execute(array(':blbalance' => $blbalance ,':curtime' => $currentt ));
  } }
?>