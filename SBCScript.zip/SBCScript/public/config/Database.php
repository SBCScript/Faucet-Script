<?php 

    define("DSN", "mysql:host=localhost;dbname=Database_name");
    define("USERNAME", "Database_username");
    define("PWD", "Database_password");

	

	try {
            
            //Create the connection 
            $db = new PDO(DSN, USERNAME, PWD);
            
            //set the PDO error mode to exception
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	}
	catch (PDOException $ex) {
            //Display error message
            echo "Connection failed ".$ex->getMessage();
        }
        
        $helpfee = "true"; //It'll give me some help (10% on each faucethub translation) for future update.if you don't want to pay make it false
        $site = "your_site_url" ; //your site URL without 'http(s)://' and also don't end with '/'
        




	