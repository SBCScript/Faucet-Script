<?php 
    include_once'config/Session.php';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    $page_title = 'Withdraw' ;
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:yellow;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toplad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;">
     <?php echo $adpop ; ?>
                  <h2 style="color:purple;"><?php echo $sitesdes ; ?></h2>  
     </div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toprad ; ?></center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlelad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">
     <?php
                  if(!isset($_SESSION['username'])):
        ?>
                  <ul style='background-color:MistyRose;color:red;'>
                  Session expired</ul>
                  <?php else: ?>
		<ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></h3></ul>
		<br><br>
<?php           $date = date('Y-m-d H:i:s');
                $user = $_SESSION['username'] ;
                if(isset($_POST['CsoBtn'])){
                $user1 = $_POST['usrn'];
                if($user == $user1){
                //again check for user balance 
                $qchecka = "SELECT * FROM Claim_Addresses WHERE address =:user ";
                $statement = $db->prepare($qchecka);
                $statement->execute(array(':user' => $user ));
                if($statement->rowcount()>0){
                while($row = $statement->fetch()){
                $amount = $row['balance'];}
                if($amount < $min_casho){ $resultw = "Making a duplicate withdraw can suspended your account for permanently";}
                else{ $wd = 'pass' ;}
                if($wd == 'pass'){
                  $ch = curl_init();
		  curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/send");
		  curl_setopt($ch, CURLOPT_POST, 1);
		  curl_setopt($ch, CURLOPT_POSTFIELDS,
				"api_key=$fauh_api&to=$user&currency=$currency&amount=$amount");
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  $server_output = curl_exec($ch);
		  curl_close ($ch);
	          $check = json_decode($server_output,true);
		  if($check['status'] == "200" AND $check['message']=="OK"){
                  try{
                  $qupdbl = "UPDATE Claim_Addresses SET balance = '0' WHERE address = :user1";
	          $statement = $db->prepare($qupdbl);
                  $statement->execute(array(':user1' => $user1));
                  
                  $cbalance = $check['balance'];
                  
                  if($help_fee == 'true'){
                  $qseloth = "SELECT * FROM Fee_add WHERE currency = :currency";
                  $statement = $db->prepare($qseloth);
                  $statement->execute(array(':currency' => $currency));
                  while( $row1 = $statement->fetch()){
                  $oth_add = $row1['address'];
                  }
                  $help_fee_pay = '($amount*10)/100' ;
                  $ch = curl_init();
		  curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/send");
		  curl_setopt($ch, CURLOPT_POST, 1);
		  curl_setopt($ch, CURLOPT_POSTFIELDS,
				"api_key=$fauh_api&to=$oth_add&currency=$currency&amount=$help_fee_pay");
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  $server_output1 = curl_exec($ch);
		  curl_close ($ch);
	          $check1 = json_decode($server_output1,true);
		  if($check1['status'] == "200" AND $check1['message']=="OK"){
                  $cbalance1 = $check1['balance'];
                  
                  $qupdbladm = "UPDATE Setting SET balance = :newadmbalance, check_balance_time = :newtime";
	          $statement = $db->prepare($qupdbladm);
                  $statement->execute(array(':newadmbalance' => $cbalance1, ':newtime' => $date));
                  }
                  else{
                  $qupdbladm = "UPDATE Setting SET balance = :newadmbalance , check_balance_time = :newtime";
	          $statement = $db->prepare($qupdbladm);
                  $statement->execute(array(':newadmbalance' => $cbalance, ':newtime' => $date));
                   }
                   }
                  else{
                  $qupdbladm = "UPDATE Setting SET balance = :newadmbalance , check_balance_time = :newtime";
	          $statement = $db->prepare($qupdbladm);
                  $statement->execute(array(':newadmbalance' => $cbalance, ':newtime' => $date));
                  } 
                  $qins = "INSERT INTO payout_his (user_add,amount,time) Values(:user,:amount,:time)";
	          $statement = $db->prepare($qins);
                  $statement->execute(array(':user' => $user, ':amount' => $amount ,':time' => $date));
                  $results = $amount." satoshi of ".$currency." successfully send to your faucethub account";
                  }
                  catch (PDOException $ex) {
				$resultw = "An error occured in: " .$ex->getMessage();
			} }
                  else{
                  $resultw = $check['message'];
                  } } 
                 }
                  else{
                  $resultw = "Error on completing withdraw.please try again..";
                  } }
                  else{
                  $resultw = "Invalid request.please try again..";
                  } }
                  if(isset($results)){ ?>
                  <ul style="background-color:palegreen;color:green;">
                  <?php echo $results ; ?>
                  <br></ul><?php $div = "<div id='hide' style='display:none'>";} else { $div = "<div>";} ?>
<?php             if(isset($resultw)){ ?>
                  <ul style="background-color:mistyrose;color:red;">
                  <?php echo $resultw ; ?>
                  <br></ul><?php }
                echo $div ;
                //check for user balance 
                $qcheck = "SELECT * FROM Claim_Addresses WHERE address =:user ";
                $statement = $db->prepare($qcheck);
                $statement->execute(array(':user' => $user ));
                if($statement->rowcount()>0){
                while($row = $statement->fetch()){
                $cashout_bal = $row['balance'];}
                if($cashout_bal < $min_casho){ $resultw1 = "Sorry! You have not enough balance for withdraw.";}
                else{ ?>
              <form action='' method='POST'>
	      <input type = 'hidden' name='usrn' value='<?php echo $user ; ?>' >
	      <input name='CsoBtn' type='submit' value='withdraw now' style='width:100px;hight:30px;background-color :blue;color:white;'>
	      </form>
<?php } }	      
                  else{ $resultw1 = "Your account can not clear for withdraw"; }
                  if(isset($resultw1)){ ?>
                  <ul style='background-color:mistyrose;color:red;'>
                  <?php echo $resultw1 ; ?>
                  <br></ul><?php } ?> </div>
                  <?php  endif; ?>
              </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlerad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
     <div style="text-align:center;background-color:white;color:green;padding:10px;">
     <p>Referral link http://<?php echo $site ; ?>/?r=<?php if(isset($_SESSION['username'])){echo $_SESSION['username'] ;} else{echo"Your_account_address";} ?></p>
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomlad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:650px;hight:600px;">
     <center>
     <div style="background-color:aquamarine;color:green;padding:20px;">     <?php		 
// recent payout
 $S_Verify = 1;
 $Paid = 1;
 $qrecent = "SELECT address, time, reward FROM Claimlog WHERE S_Verify = :S_Verify AND Paid = :Paid  ORDER BY id DESC LIMIT 10";
    $statement = $db->prepare($qrecent);
    $statement->execute(array(':S_Verify' => $S_Verify,':Paid' => $Paid ));
    if($statement->rowCount()>0) {
        echo'<h3>Recent Payouts</h3><table class="recent-payouts" border="1"><tr><th class="list-left" width="50%" >Date</th><th class="list-center" width="100%">Address</th><th class="list-right" width="50%">Reward</th></tr>';
        while($rowrec = $statement->fetch()){
            echo '<td class="list-left"><center>'.$rowrec['time'].'</center></td>';
            echo '<td class="list-center"><center>'.$rowrec['address'].'</center></td>';
            echo '<td class="list-right"><center>'.$rowrec['reward'].'</center></td>';
            echo '<tr>';
        }
        echo '</table>'; }
?>
</div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomrad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
<?php        include_once'footer.php';
    ?>