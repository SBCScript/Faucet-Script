<?php 
    include_once'config/Session.php';
    $page_title = 'FAQs';
/* ############################################################################################################################# This is Faucet script for free download and create a new faucet site.Script is coded by Script4download 
blog Author site URL https://script4download.blogspot.com/.For future update visit the site/blog and view the post related to this faucet script.The script is tested at https://webeyesoft.com.If you think this script is helpful and want to help the Author, you can send a small crypto help at BTC-> 1CSmVA8UruFuEURMkAydH5116coL67AzK8 ,OR DOGE-> DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq .Thanku for using the script and all the best with your faucet site earn with strong future .#############################################################################################$################
*/
    include_once'config/Database.php';
    include_once'config/Utilities.php';
    include_once'Setting.php';
    include_once'header.php';
?>    
     <div style="text-align:center;background-color:yellow;">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toplad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center>
     <div style="text-align:center;">
     <?php echo $adpop ; ?>
                  <h2 style="color:purple;"><?php echo $sitesdes ; ?></h2>  
     </div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:300px;hight:200px;">
     <center><?php echo $toprad ; ?></center>
     </div>
     </td>
     </tr>
     </table></div>
     <div style="text-align:center;background-color:violet;padding:5px;">
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlelad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:600px;hight:600px;">
     <center>
     <div style="text-align:center;padding: 20px;">

                  <?php if(isset($_SESSION['username'])){ ?>
		  <ul style='background-color:palegreen;color:green;'>
                  <h3>You are logged in as <?php echo $_SESSION['username']; ?></h3></ul><?php } ?>
		<br>
<?php           
                $q = "SELECT faqs FROM Other ";
                $statement = $db->prepare($q);
                $statement->execute(array());
                while($row = $statement->fetch()){
                $faq = $row['faqs'];} ?>
                <H2>FAQs</H2>
                <?php  echo $faq; ?>
              </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:160px;hight:600px;">
     <center><?php echo $middlerad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
     <div style="text-align:center;background-color:white;color:green;padding:10px;">
     <p>Referral link http://<?php echo $site ; ?>/?r=<?php if(isset($_SESSION['username'])){echo $_SESSION['username'] ;} else{echo"Your_account_address";} ?></p>
     </div>
     <div style="text-align:center;background-color:lightblue;padding:20px">
     <table align ="center">
     <tr><td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomlad ; ?></center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:650px;hight:600px;">
     <center>
     <div style="background-color:aquamarine;color:green;padding:20px;">     <?php		 
// recent payout
 $S_Verify = 1;
 $Paid = 1;
 $qrecent = "SELECT address, time, reward FROM Claimlog WHERE S_Verify = :S_Verify AND Paid = :Paid  ORDER BY id DESC LIMIT 10";
    $statement = $db->prepare($qrecent);
    $statement->execute(array(':S_Verify' => $S_Verify,':Paid' => $Paid ));
    if($statement->rowCount()>0) {
        echo'<h3>Recent Payouts</h3><table class="recent-payouts" border="1"><tr><th class="list-left" width="50%" >Date</th><th class="list-center" width="100%">Address</th><th class="list-right" width="50%">Reward</th></tr>';
        while($rowrec = $statement->fetch()){
            echo '<td class="list-left"><center>'.$rowrec['time'].'</center></td>';
            echo '<td class="list-center"><center>'.$rowrec['address'].'</center></td>';
            echo '<td class="list-right"><center>'.$rowrec['reward'].'</center></td>';
            echo '<tr>';
        }
        echo '</table>'; }
?>
</div>
     </center>
     </div>
     </td>
     <td>
     <div style="background-color:white;width:120px;hight:600px;">
     <center><?php echo $buttomrad ; ?></center>
     </div>
     </td>
     </tr>
     </table>
     </div>
<?php        include_once'footer.php';
    ?>