Thanku for downloading the faucet script.The script may be update in future.So you may check it's update version at https://script4download.blogspot.com/ .

Requirements:-
1. PHP 5.6 or above (PDO)
2. Database
3. Curl must enable
4. allow_url_fopen on (set this on php.ini)

Installation:->
Unzipped the download zip file.Go to your webhost and create a new database.import the SQL file(getting after unzipped the zip file) to new created database.upload public folder's all files and folders to your host's public_hrml folder.
Open config/Database.php and includes/Database.php files and edit the deatails of files with your database credits (database name,database username,database password).In includes/Database.php edit line 23 & 24 with your admin username & password.Admin username and password must be secretwords to safe from hackers and don't use as cryptoaddress for admin username.In config/Database.php edit line 23 for Author help fee.If you don't want to pay fee to Author of this faucet script make it false otherwise make it true .At line 24 write your site full url without 'http(s)://' and end without '/' for example domain.com or sub.domain.com or domain.com/sub .You should use this script for only domain.com for better use in future updates.

Configuration:->
 To make more secure your admin area from hackers access,change admin folder name with your secret word such as ad_min,ad_mi_n,admin_cp (only for example) etc.
Create an account at https://iphub.info and choose a free plan for ip service for safe your faucet site against Proxy,VPN,TOR,BadIP etc.After issue an api key , open checkip.php file and at line 24 replace the word your_iphub_api with your issued api key.
There are more than 6000 blackip list are denny to access in site at .htaccess file.you can update this with help of https://pastebin.com/KAZ8RAQ8 .The .htaccess file also stop black IPs.If your site facing any problem such as '500 error page not found' or something like this error, delete this .htaccess file because the file not supported ar all hosting service. You may create new .htaccesa file which ideal for your hosting. 
Now move to your admin area and login with your admin details.In Faucet Setting tab page you can control of Your faucet frant (user area and also for search engine).In Template setting page you can manage your faucet ads.here you can add up to 6 ads and one pop ads (Use HTML code carefully otherwise your faucet will misbehave).
In short link manage page you can add any number of shortlink provider service. To add shortlink service, you need shortlink URL (Without 'http(s)://' and end without'/' for example domain.com) and api key.If you inserted wrong URL or api the shortlink preparation will failed and then system use Auther shortlink for saving to user to go bad way.
To make active or inactive your faucet use use active and inactive page.
Here You can easly manage blackip and whiteip address.These IPS filtered by system in iphub response.If you think someone cheat with your faucet (use static section to check this),Add the IP to blackip list and wise versa.Similarly add cheater address at black address page.
Manage FAQs of your faucet at FAQs manage page and News at News manage page.
Hey if you want to edit the script feel free to do so but carefully otherwise faucet will mis behave.

Update 19 DEC 2018 :->
Now faucet supported with four different type captcha services (Google recaptcha,Solvemedia captcha,Rain captcha  and coinhive captcha) and Faucet owner can set 'Forse on shortlink verification'.Default the option is false that's mean user of the faucet can earn 20% of reward without verify short link(s).If faucet owner doesn't want to enable this option, Open Setting.php file and at line 39( $shortlink_forse = 'false' ; ) replace false from true.
You can also enable or disable any captcha services by set true or false on Setting.php file.Enable a captcha service, you must set requirement (pubic key,secret key etc).Default all captcha service are disable excluding Google recaptch(it can never disable).Suppose you want to enable Solve media captcha service.open Setting.php file at line 43 ($solve_media_captcha = 'false' ;) replace false from true and set lines 44,45 and 46 for your challenge key,verification key and verification hash key.Similarly you can manage other captcha services.that's it.

Previous version of script can update by updating Setting.php,index.php,payout.php,ParseLogin.php files and adding files solvemedialib.php and direct_claim.php .

Support:->
If you facing any problem to set your faucet site,Comments with your problems below my post on blogger I'll happy to solve your problems.

Help:->
Hey if you think the script is useful and want to help script Author ,Welcome at BTC => 1CSmVA8UruFuEURMkAydH5116coL67AzK8
AND at DOGE => DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq
Once again thanks for downloading the script and all the best for your new faucet site.