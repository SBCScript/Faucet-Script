Thanku for downloading the faucet script.The script may be update in future.So you may check it's update version at https://script4download.blogspot.com/ .

Requirements:-
1. PHP 5.6 or above
2. Database (PDO)
3. Curl must enable
4. allow_url_fopen on (php INI)

Installation:-
Unzipped the download zip file.Go to your webhost and create a new database.import the SQL file(getting after unzipped the zip file) to new created database.upload public folder's all files and folders to your host's public_hrml folder.
Open config/Database.php and includes/Database.php edit with your database credits (database name,database username,database password).In includes/Database.php edit line 23 & 24 with your admin username & password.Admin username and password must be secret to safe from hackers and don't use as cryptoaddress for admin username.In config/Database.php edit line 23 for Author help fee.If you don't want to pay fee to Author of this faucet script make it false otherwise make it true .At line 24 write your site full url without 'http(s)://' and end without '/' for example domain.com or sub.domain.com or domain.com/sub .
Configuration:->
To make more secure your admin area from user access,change admin folder name with your secret word such as ad_min,ad_mi_n,admin_cp etc.
Create an account at https://iphub.info and choose a free plan for safe your faucet against Proxy,VPN,TOR,BadIP etc.Issue an apikey and now open checkip.php file.at line 24 replace the word your_iphub_api with your issued api key.
There are more than 6000 blackip list are denny to access in site at .htaccess file.you can update this with help of https://pastebin.com/KAZ8RAQ8 .
Now move to your admin area and login with admin details.In Faucet Setting tab page you have to Set Your faucet face for user and also for search engine.In Template setting page you can manage your faucet ads.here you can add up to 6 ads and one pop ads (Use HTML code carefully otherwise your faucet will misbehave).
In short link manage page you can add any number of shortlink provider service. To add shortlink service, you need shortlink URL (Without 'http(s)://' and end without'/' for example domain.com) and api key.If you inserted wrong URL or api the shortlink preparation will failed and then system use Auther shortlink for saving to user to go bad way.
To make active or inactive your faucet use use active and inactive page.
Here You can easly manage blackip and whiteip address.These IPS filtered by system in iphub response.If you think someone cheat with your faucet (use static section to check this),Add the IP to blackip list and wise versa.Similarly add cheater address at black address page.
Manage FAQs of your faucet at FAQs manage page and News at News manage page.
Hey if you want to edit the script feel free to do so but carefully otherwise faucet will mis behave.

Hey if you think the script is useful and want to help script Author ,Welcome at BTC => 1CSmVA8UruFuEURMkAydH5116coL67AzK8
AND at DOGE => DSQa9cPdqY3D54XBjohqkH7qFWgQ5dJVHq
Once again thanks for downloading the script and all the best for your new faucet site.