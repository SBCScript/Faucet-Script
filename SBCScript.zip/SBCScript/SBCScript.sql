-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 09, 2019 at 02:43 PM
-- Server version: 5.7.25
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bitcoins_F`
--

-- --------------------------------------------------------

--
-- Table structure for table `Blackip`
--

CREATE TABLE `Blackip` (
  `id` int(30) NOT NULL,
  `ip_add` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blackip`
--

INSERT INTO `Blackip` (`id`, `ip_add`) VALUES
(2, '5.255.250.111'),
(3, '37.9.87.223'),
(4, '66.249.65.201'),
(5, '66.249.65.206'),
(6, '66.249.73.29'),
(7, '66.249.65.202'),
(8, '213.239.217.45'),
(9, '209.133.195.109'),
(10, '46.105.236.211'),
(11, '77.88.47.69'),
(12, '46.229.168.146'),
(13, '66.249.66.49'),
(14, '46.4.61.205'),
(15, '66.249.66.47'),
(16, '66.249.66.54'),
(17, '136.243.37.219'),
(18, '173.232.242.34'),
(19, '37.139.52.40'),
(20, '104.248.2.98'),
(21, '104.248.2.211'),
(22, '142.93.187.83'),
(23, '52.53.201.78'),
(24, '88.198.43.49'),
(25, '46.229.168.136'),
(26, '46.229.168.150'),
(27, '66.249.73.28'),
(28, '46.229.168.139'),
(29, '46.229.168.135'),
(30, '141.8.143.141'),
(31, '37.9.87.204'),
(32, '178.154.246.128'),
(33, '46.229.168.142'),
(34, '5.9.113.137'),
(35, '173.249.26.213'),
(36, '35.187.132.182'),
(37, '35.187.132.183'),
(38, '178.154.244.142'),
(39, '66.249.66.34'),
(40, '151.236.8.47'),
(41, '93.158.161.141');

-- --------------------------------------------------------

--
-- Table structure for table `Black_address`
--

CREATE TABLE `Black_address` (
  `id` int(30) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Claimlog`
--

CREATE TABLE `Claimlog` (
  `id` int(11) NOT NULL,
  `address` varchar(110) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `time` varchar(255) NOT NULL DEFAULT '0000-00-00 00:00:00.000000',
  `shortlink1` varchar(255) NOT NULL,
  `shortlink2` varchar(255) NOT NULL,
  `v_code` varchar(255) NOT NULL,
  `reward` varchar(16) NOT NULL DEFAULT '0',
  `S_Verify` varchar(30) NOT NULL,
  `Paid` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Claimlog`
--

INSERT INTO `Claimlog` (`id`, `address`, `ip`, `time`, `shortlink1`, `shortlink2`, `v_code`, `reward`, `S_Verify`, `Paid`) VALUES
(180, '1CSmVA8UruFuEURMkAydH5116coL67AzK8', '27.97.2.34', '2019-02-08 06:20:49', 'oturl.com', 'cuturl.in', 'kmGWjEfnNcIFwuV7YJsBRQx26Lh1br', '5', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `Claim_Addresses`
--

CREATE TABLE `Claim_Addresses` (
  `address` varchar(60) NOT NULL,
  `ref_add` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL DEFAULT '0',
  `Currency` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Claim_Addresses`
--

INSERT INTO `Claim_Addresses` (`address`, `ref_add`, `balance`, `Currency`) VALUES
('1CSmVA8UruFuEURMkAydH5116coL67AzK8', '0', '0', 'BTC'),
('16xLB9ZRfvcu5rh6XbFuFThDaZHnaVz3wY', '0', '0', 'BTC'),
('3JLHoqqdNXmosUdZkkLtJjiikgUPzmg4Th', '0', '5', 'BTC'),
('1DoXWHPipd9eiKd6VibX8W5YYSht3LbpQd', '0', '0', 'BTC'),
('161UmBXX3vv2b9EZXNcswFX2tsHS6mUPBX', '0', '5', 'BTC'),
('19hXhZtrjJg1qFV8M1TK7aoQZZid2PWYK4', '0', '0', 'BTC');

-- --------------------------------------------------------

--
-- Table structure for table `Fee_add`
--

CREATE TABLE `Fee_add` (
  `id` int(11) NOT NULL,
  `currency` varchar(110) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Fee_add`
--

INSERT INTO `Fee_add` (`id`, `currency`, `address`) VALUES
(138, 'BTC', '1CSmVA8UruFuEURMkAydH5116coL67AzK8'),
(139, 'ETH', '0x451cc626335f023b822b91fb1d56a812f3d6a5ed'),
(141, 'XMR', '42FzB9D2ZaARSBh6eJG8jqEgerj26ANLp9m4RGUZU5ZZ4YWBdZggjCxMNofaHps2VuF3tUB7u7VMhDjV6yskqJY43ixn6d3'),
(142, 'LTC', 'LbRLMW1U41db1t5wNQjnoSBZBbg2Dkrxka'),
(143, 'DOGE', 'DSC3BHkr6J32zFEWK55PqKCsAr8cf7MspU'),
(144, 'BCH', '1FcgoyunahiW1wwu5HmTpDeEtx2XCe9SLK'),
(145, 'ZEC', 't1VMNRhfxKyqV1L5pYVb1L1D1c82UzbAHEU'),
(146, 'DGB', 'DQhQnwpSM9RXzrnYr7nZQ3CmoUYi2XS43R'),
(147, 'BTX', 'sVF8fUsy3kid53TPL476FteW8ss8YrxD1G'),
(148, 'BLK', 'BKdW7LYLLkvaX1WHENw1UpWpnfXh1TPMxL'),
(149, 'DASH', 'XoewvKtiuGqikzWqBwii8D3biypzUAr586'),
(150, 'PPC', 'PChBnZ8phjanbHmXcnff4iGSsg5Fi4mT2w'),
(151, 'XPM', 'APBkSMyDVkcLXNECqFyMHq5GcrdKiNTCro'),
(152, 'POT', 'PUUNsqp2DPXS6gk93PfwSLAAnqRPSSpoqZ');

-- --------------------------------------------------------

--
-- Table structure for table `offer_trana`
--

CREATE TABLE `offer_trana` (
  `id` int(15) NOT NULL,
  `transid` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `service` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Other`
--

CREATE TABLE `Other` (
  `faqs` varchar(32000) NOT NULL,
  `news` varchar(32000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Other`
--

INSERT INTO `Other` (`faqs`, `news`) VALUES
('<b>Q. How to use this faucet?</b><br>\r\n<b>A.</b> You need a account at <a href=\"https://faucethub.io\">Faucethub </a> for all your claiming reward to withdraw.You have to login or register here using the crypto address linked with Faucethub.', 'We are happy to announce our new faucet site for claim free reward to your faucethub account.');

-- --------------------------------------------------------

--
-- Table structure for table `payout_his`
--

CREATE TABLE `payout_his` (
  `id` int(6) NOT NULL,
  `user_add` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payout_his`
--

INSERT INTO `payout_his` (`id`, `user_add`, `amount`, `time`) VALUES
(4, '1CSmVA8UruFuEURMkAydH5116coL67AzK8', '10', '2018-12-10 05:01:41'),
(5, '1CSmVA8UruFuEURMkAydH5116coL67AzK8', '10', '2018-12-10 06:35:20');

-- --------------------------------------------------------

--
-- Table structure for table `Setting`
--

CREATE TABLE `Setting` (
  `balance` varchar(255) NOT NULL DEFAULT '0',
  `sitename` varchar(255) NOT NULL,
  `S_description` varchar(255) NOT NULL DEFAULT 'Short description',
  `L_description` varchar(5000) NOT NULL DEFAULT 'Long description',
  `Site_keyword` varchar(255) NOT NULL DEFAULT 'Site keyword',
  `adpop` varchar(600) NOT NULL,
  `top_left_ad` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Top left ad (300×250)',
  `top_right_ad` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Top right ad (300×250)',
  `middle_left_ad` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'middle left ad (160×600)',
  `middle_right_ad` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'middle right ad (160×600)',
  `bottom_left_ad` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'bottom left ad (120×600)',
  `bottom_right_ad` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'bottom right ad (120×600)',
  `api` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `reward` varchar(255) NOT NULL,
  `refercomsn` varchar(255) NOT NULL,
  `claimlimit` varchar(255) NOT NULL,
  `timediffernce` varchar(30) NOT NULL DEFAULT '5',
  `active` varchar(255) NOT NULL,
  `shortlink_type` int(30) NOT NULL DEFAULT '2',
  `min_cashout` varchar(255) NOT NULL,
  `check_balance_time` varchar(255) NOT NULL DEFAULT '0',
  `Google_pbk` varchar(255) NOT NULL DEFAULT '0',
  `Google_sck` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Setting`
--

INSERT INTO `Setting` (`balance`, `sitename`, `S_description`, `L_description`, `Site_keyword`, `adpop`, `top_left_ad`, `top_right_ad`, `middle_left_ad`, `middle_right_ad`, `bottom_left_ad`, `bottom_right_ad`, `api`, `currency`, `reward`, `refercomsn`, `claimlimit`, `timediffernce`, `active`, `shortlink_type`, `min_cashout`, `check_balance_time`, `Google_pbk`, `Google_sck`) VALUES
('60512', 'Your Faucer name', 'Short description', 'Long description', 'Site keyword', 'Pop ads', 'Top left ads of dimension (300Ã—250)', 'Top right ads of dimension (300Ã—250)', 'Middle left ads of dimension (160Ã—600)', 'Middle right ads of dimension (160Ã—600)', 'Bottom left ads of dimension (120Ã—600)', 'Bottom right ads of dimension (120Ã—600)', 'Faucethub api', 'BTC', '20', '5', '12', '60', '0', 1, '200', '2019-02-09 02:32:41', 'Google recaptcha public key', 'Google recaptcha secret key');

-- --------------------------------------------------------

--
-- Table structure for table `Shortlink_selected`
--

CREATE TABLE `Shortlink_selected` (
  `shortlink` varchar(32) NOT NULL DEFAULT '',
  `api` varchar(255) NOT NULL DEFAULT '0',
  `prt` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Shortlink_selected`
--

INSERT INTO `Shortlink_selected` (`shortlink`, `api`, `prt`) VALUES
('tokenfly.pw', '44b55bfc065dad669aa5a067adb88208be816374', 'Yes'),
('time4earn.com', '3abc1e41ade69db5e3398ea029c0aa9fb23b5653', 'No'),
('cuturl.in', '3690c91ff64ef0569e65f1679dab3900ade11708', 'No'),
('faucety.cc', 'f321ee29a28b909a6e95a48f958a8f712c060b6a', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `SL_oth`
--

CREATE TABLE `SL_oth` (
  `id` int(11) NOT NULL,
  `shortlink` varchar(32) NOT NULL DEFAULT '',
  `api` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SL_oth`
--

INSERT INTO `SL_oth` (`id`, `shortlink`, `api`) VALUES
(151, 'oturl.com', '5f96a1dd20ae5d8843fc0071978007f97320c372'),
(155, 'itiurl.co', 'bfb205ed9e586ab0ed0d0d234aaa6dbc35d86cab');

-- --------------------------------------------------------

--
-- Table structure for table `Whiteip`
--

CREATE TABLE `Whiteip` (
  `id` int(30) NOT NULL,
  `ip_add` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Whiteip`
--

INSERT INTO `Whiteip` (`id`, `ip_add`) VALUES
(2, '27.97.244.80'),
(3, '27.97.4.77'),
(4, '27.97.245.167'),
(5, '106.76.152.155'),
(6, '27.97.5.100'),
(7, '27.97.10.132'),
(8, '23.237.4.26'),
(9, '27.97.11.17'),
(10, '27.97.6.169'),
(11, '109.254.102.16'),
(12, '39.41.177.240'),
(13, '77.75.78.172'),
(14, '27.97.255.243'),
(15, '27.97.11.161'),
(16, '180.76.15.20'),
(17, '180.76.15.153'),
(18, '27.97.243.129'),
(19, '196.195.216.44'),
(20, '2600:1700:8090:45c0:ad1c:c05b:583f:7bb7'),
(21, '27.97.248.95'),
(22, '27.97.14.245'),
(23, '89.64.11.50'),
(24, '187.189.49.157'),
(25, '95.222.31.75'),
(26, '5.172.238.230'),
(27, '202.14.123.60'),
(28, '185.20.6.88'),
(29, '82.137.25.6'),
(30, '114.142.171.7'),
(31, '112.110.108.82'),
(32, '117.204.209.66'),
(33, '68.203.13.109'),
(34, '101.114.132.57'),
(35, '112.134.16.221'),
(36, '92.232.230.230'),
(37, '186.155.13.246'),
(38, '60.225.212.40'),
(39, '27.97.2.111'),
(40, '110.137.20.211'),
(41, '207.241.230.164'),
(42, '180.217.107.85'),
(43, '27.97.243.195'),
(44, '106.76.157.172'),
(45, '180.76.15.29'),
(46, '27.97.5.166'),
(47, '106.76.156.183'),
(48, '59.95.125.94'),
(49, '112.215.219.225'),
(50, '2.44.227.62'),
(51, '46.185.68.83'),
(52, '86.120.227.27'),
(53, '106.76.156.5'),
(54, '168.211.58.113'),
(55, '37.111.130.91'),
(56, '109.69.5.208'),
(57, '115.135.149.187'),
(58, '77.75.77.17'),
(59, '79.101.139.212'),
(60, '85.206.237.160'),
(61, '1.52.124.210'),
(62, '39.40.164.43'),
(63, '27.97.252.162'),
(64, '27.97.247.232'),
(65, '27.97.2.226'),
(66, '27.97.6.89'),
(67, '38.130.165.235'),
(68, '38.79.214.244'),
(69, '27.97.7.211'),
(70, '60.191.38.77'),
(71, '91.210.144.151'),
(72, '27.97.10.240'),
(73, '106.76.156.234'),
(74, '209.17.96.250'),
(75, '27.97.240.200'),
(76, '106.76.146.193'),
(77, '199.192.19.215'),
(78, '27.97.2.34'),
(79, '27.97.243.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Blackip`
--
ALTER TABLE `Blackip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Black_address`
--
ALTER TABLE `Black_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Claimlog`
--
ALTER TABLE `Claimlog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_ip_time_shortink` (`address`,`ip`,`time`,`shortlink1`);

--
-- Indexes for table `Claim_Addresses`
--
ALTER TABLE `Claim_Addresses`
  ADD PRIMARY KEY (`address`);

--
-- Indexes for table `Fee_add`
--
ALTER TABLE `Fee_add`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_ip_time_shortink` (`currency`,`address`);

--
-- Indexes for table `offer_trana`
--
ALTER TABLE `offer_trana`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payout_his`
--
ALTER TABLE `payout_his`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Shortlink_selected`
--
ALTER TABLE `Shortlink_selected`
  ADD KEY `address_ip_time_shortink` (`shortlink`);

--
-- Indexes for table `SL_oth`
--
ALTER TABLE `SL_oth`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_ip_time_shortink` (`shortlink`);

--
-- Indexes for table `Whiteip`
--
ALTER TABLE `Whiteip`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Blackip`
--
ALTER TABLE `Blackip`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `Black_address`
--
ALTER TABLE `Black_address`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Claimlog`
--
ALTER TABLE `Claimlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `Fee_add`
--
ALTER TABLE `Fee_add`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `offer_trana`
--
ALTER TABLE `offer_trana`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payout_his`
--
ALTER TABLE `payout_his`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `SL_oth`
--
ALTER TABLE `SL_oth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `Whiteip`
--
ALTER TABLE `Whiteip`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
